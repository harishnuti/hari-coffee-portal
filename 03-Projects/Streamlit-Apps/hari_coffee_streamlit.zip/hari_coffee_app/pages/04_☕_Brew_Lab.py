import streamlit as st
import pandas as pd
import sys
import os
from datetime import datetime, timedelta
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import get_all_entries, insert_saved_recipe, get_saved_recipes, delete_saved_recipe
from components.charts import render_degassing_gauge
from components.entry_card import render_entry_table

st.set_page_config(page_title="Brew Lab - Hari's Coffee Archive", layout="wide")

st.title("☕ Brew Lab")

tab1, tab2 = st.tabs(["⚗️ Recipe Calculator", "📚 Saved Recipes"])

with tab1:
    st.subheader("Generate Optimal Recipe")
    
    col1, col2 = st.columns(2)
    
    with col1:
        origin = st.selectbox("Origin", ['Colombia', 'Brazil', 'Ethiopia', 'Panama', 'Peru', 'Ecuador', 'Kenya', 'Indonesia', 'Other'])
        process = st.selectbox("Process", ['Washed', 'Natural', 'Red Honey', 'Anaerobic Natural', 'Double Anaerobic', 'Honey'])
        roast_age = st.slider("Days since roast", 0, 60, 18)
    
    with col2:
        varietal = st.selectbox("Varietal", ['Geisha', 'Gesha', 'Sudan Rume', 'Heirloom', 'Arara', 'Typica', 'Other'])
        brew_method = st.selectbox("Brew Method", ['V60 Pour-over', 'Flat-Bottom (Hario Alpha)', 'xBloom Automated', 'Origami Conical', 'Flatbed Dripper'])
    
    # Degassing status
    st.markdown("### 🌡️ Degassing Status")
    gauge = render_degassing_gauge((datetime.now() - timedelta(days=roast_age)).isoformat())
    st.plotly_chart(gauge, use_container_width=True)
    
    if st.button("⚗️ Calculate Optimal Recipe", type="primary"):
        # Recipe logic
        if varietal in ['Geisha', 'Gesha', 'Wush Wush', 'Heirloom']:
            ratio = 1/17
            temp = "92→75→92°C" if origin == 'Ecuador' else "92°C"
        elif 'Anaerobic' in process:
            ratio = 1/14
            temp = "90°C"
        elif 'Honey' in process:
            ratio = 1/16
            temp = "80→95→80°C"
        else:
            ratio = 1/15
            temp = "92°C"
        
        dose = 15.0
        yield_g = round(dose / ratio)
        
        # Thermal predictions
        if 'Honey' in process:
            hot_note = "Jammy fruit forward"
            mid_note = "Sweet body builds"
            cool_note = "Clean honey finish"
        elif 'Anaerobic' in process:
            hot_note = "Estery, wine-like"
            mid_note = "Savory depth"
            cool_note = "Long complex finish"
        else:
            hot_note = "Bright floral/citrus"
            mid_note = "Balanced sweetness"
            cool_note = "Clean, structured finish"
        
        recipe = {
            'recipe_name': f"{origin} {varietal} {process} - {brew_method}",
            'origin': origin,
            'varietal': varietal,
            'process': process,
            'brew_method': brew_method,
            'dose_g': dose,
            'yield_g': yield_g,
            'ratio': f"1:{yield_g/dose:.1f}",
            'temp_c': temp,
            'bloom_g': 30,
            'bloom_time_s': 30,
            'pour_notes': f"Triple temp cascade recommended. Hot: {hot_note}. Mid: {mid_note}. Cool: {cool_note}",
            'hot_note': hot_note,
            'mid_note': mid_note,
            'cool_note': cool_note
        }
        
        # Display recipe
        st.success("✅ Recipe Calculated!")
        
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Dose", f"{recipe['dose_g']}g")
        col2.metric("Yield", f"{recipe['yield_g']}g")
        col3.metric("Ratio", recipe['ratio'])
        col4.metric("Temp", recipe['temp_c'])
        
        st.subheader("Pour Structure")
        st.write(f"**Bloom:** {recipe['bloom_g']}g for {recipe['bloom_time_s']}s")
        st.write(f"**Main Pour:** {recipe['pour_notes']}")
        
        st.subheader("Expected Flavour Phases")
        p1, p2, p3 = st.columns(3)
        p1.info(f"🔥 Hot: {recipe['hot_note']}")
        p2.info(f"🌡️ Mid: {recipe['mid_note']}")
        p3.info(f"❄️ Cool: {recipe['cool_note']}")
        
        # Similar entries
        st.subheader("📚 Similar Archive Entries")
        similar = get_all_entries()
        if not similar.empty:
            similar = similar[similar['process'].str.contains(process[:5], case=False, na=False)].head(3)
            if not similar.empty:
                render_entry_table(similar)
        
        if st.button("💾 Save This Recipe"):
            insert_saved_recipe(recipe)
            st.success("Recipe saved to library!")

with tab2:
    st.subheader("Saved Recipes")
    recipes = get_saved_recipes()
    
    if recipes.empty:
        st.info("No saved recipes yet. Calculate one above!")
    else:
        for _, r in recipes.iterrows():
            with st.container():
                col1, col2 = st.columns([5, 1])
                col1.write(f"**{r.get('recipe_name', 'Recipe')}**")
                col1.caption(f"{r.get('origin')} • {r.get('varietal')} • {r.get('process')} • {r.get('brew_method')}")
                if col2.button("🗑️ Delete", key=f"del_recipe_{r.get('id')}"):
                    delete_saved_recipe(r.get('id'))
                    st.rerun()