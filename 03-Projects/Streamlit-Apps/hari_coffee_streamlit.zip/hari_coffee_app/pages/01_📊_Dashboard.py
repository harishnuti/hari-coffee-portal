import streamlit as st
import pandas as pd
from datetime import datetime
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import (
    get_all_entries, get_entries_count, get_unique_cafes, 
    get_unique_cities, get_unique_varietals, get_top_entries
)
from components.charts import (
    render_process_donut, render_origin_bar, render_monthly_timeline,
    render_palate_radar, render_grinder_bar, render_world_map
)
from components.entry_card import render_entry_card

st.set_page_config(page_title="Dashboard - Hari's Coffee Archive", layout="wide")

st.title("📊 Coffee Archive Dashboard")
st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M')}")

# Get data
df = get_all_entries()

# ROW 1 — KPI METRICS
st.markdown("### 📈 Key Metrics")

col1, col2, col3, col4 = st.columns(4)

with col1:
    total = get_entries_count()
    st.metric("Total Audits", total, delta="+5 this month")

with col2:
    cafe_count = len(get_unique_cafes())
    st.metric("Unique Cafes", cafe_count)

with col3:
    city_count = len(get_unique_cities())
    st.metric("Cities Visited", city_count)

with col4:
    varietal_count = len(get_unique_varietals())
    st.metric("Varietals Documented", varietal_count)

# ROW 2 — TOP ENTRIES
st.markdown("### ⭐ Top Rated Entries")

top_5 = get_top_entries(5)
if not top_5.empty:
    cols = st.columns(5)
    for idx, (_, entry) in enumerate(top_5.iterrows()):
        with cols[idx]:
            render_entry_card(entry.to_dict())
else:
    st.info("No entries yet. Add your first audit!")

# ROW 3 — CHARTS
st.markdown("### 📊 Process & Origin Breakdown")

col1, col2 = st.columns(2)

with col1:
    st.plotly_chart(render_process_donut(df), use_container_width=True)

with col2:
    st.plotly_chart(render_origin_bar(df), use_container_width=True)

# ROW 4 — TIMELINE
st.markdown("### 📅 Audit Timeline")

st.plotly_chart(render_monthly_timeline(df), use_container_width=True)

# ROW 5 — PALATE & GRINDER
st.markdown("### 🎯 Palate Profile & Hardware")

col1, col2 = st.columns(2)

with col1:
    scores = {'Acid': 8.2, 'Body': 7.5, 'Sweetness': 8.8, 'Clarity': 9.1, 'Complexity': 8.4}
    st.plotly_chart(render_palate_radar(scores), use_container_width=True)

with col2:
    st.plotly_chart(render_grinder_bar(df), use_container_width=True)

# ROW 6 — WORLD MAP
st.markdown("### 🌍 Origins Explored")

st.plotly_chart(render_world_map(df), use_container_width=True)

# ROW 7 — RECENT ENTRIES
st.markdown("### 🕐 Recent Entries")

recent = df.head(8) if not df.empty else pd.DataFrame()
if not recent.empty:
    from components.entry_card import render_entry_table
    render_entry_table(recent)
else:
    st.info("Start building your archive!")