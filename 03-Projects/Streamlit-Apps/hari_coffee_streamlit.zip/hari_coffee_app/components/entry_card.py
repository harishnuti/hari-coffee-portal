import streamlit as st
import pandas as pd
from datetime import datetime

PROCESS_COLORS = {
    'Washed': '#4a7fc1',
    'Natural': '#fb923c',
    'Red Honey': '#c9a84c',
    'Extended Fermentation Honey': '#c9a84c',
    'Anaerobic Natural': '#e05252',
    'Anaerobic Washed': '#e05252',
    'Double Anaerobic': '#e05252',
    'Washed Co-ferment': '#a78bfa',
    'Co-ferment': '#a78bfa',
    'Natural Fermentation': '#fb923c',
    'Semi-Washed / Wet-Hulled': '#6b7280',
    'Experimental Anaerobic': '#e05252',
    'Multi-stage Anaerobic': '#e05252',
    'Unknown': '#6b7280'
}

def render_entry_card(entry: dict, expanded: bool = False):
    """Renders a single archive entry as a styled card"""
    with st.container():
        # Header
        col1, col2, col3 = st.columns([4, 1.5, 1])
        
        with col1:
            st.markdown(f"### ☕ {entry.get('coffee_name', 'Unknown Coffee')}")
            st.caption(f"**{entry.get('cafe_name', 'Unknown Cafe')}** • {entry.get('city', '')} • {entry.get('date', '')}")
        
        with col2:
            process = entry.get('process', 'Unknown')
            color = PROCESS_COLORS.get(process, '#6b7280')
            st.markdown(f"<span style='background-color:{color}; color:white; padding:2px 8px; border-radius:4px; font-size:11px'>{process}</span>", unsafe_allow_html=True)
        
        with col3:
            rating = entry.get('rating', 0)
            stars = "★" * int(rating) + "☆" * (5 - int(rating))
            st.markdown(f"<span style='color:#c9a84c; font-size:16px'>{stars}</span>", unsafe_allow_html=True)
        
        # Verdict preview
        verdict = entry.get('your_verdict', '')
        if verdict:
            preview = verdict[:120] + "..." if len(verdict) > 120 else verdict
            st.markdown(f"*{preview}*")
        
        # Technical note
        tech = entry.get('technical_enrichment', '')
        if tech:
            st.caption(f"🔬 {tech[:80]}..." if len(tech) > 80 else f"🔬 {tech}")
        
        # Sentiment score
        sentiment = entry.get('sentiment_score', 0)
        if sentiment:
            st.progress(min(sentiment / 10, 1.0))
            st.caption(f"Sentiment: {sentiment:.1f}/10")
        
        if expanded:
            st.divider()
            # Full details
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Varietal:** {entry.get('varietal', 'Unknown')}")
                st.write(f"**Roast Level:** {entry.get('roast_level', 'Unknown')}")
                st.write(f"**Brew Method:** {entry.get('brew_method', 'Unknown')}")
                st.write(f"**Grinder:** {entry.get('grinder', 'Unknown')}")
            with col2:
                st.write(f"**Dose/Yield:** {entry.get('dose_g', '?')}g → {entry.get('yield_g', '?')}g ({entry.get('ratio', 'Unknown')})")
                st.write(f"**Price:** {entry.get('price_local', 'N/A')}")
                st.write(f"**Official Notes:** {entry.get('official_notes', 'N/A')}")
            
            st.write("**Your Verdict:**")
            st.write(verdict)
            
            if tech:
                st.write("**Technical Enrichment:**")
                st.write(tech)
            
            # Action buttons
            col1, col2, col3 = st.columns(3)
            if col1.button("✏️ Edit", key=f"edit_{entry.get('id', 0)}"):
                st.session_state['edit_entry_id'] = entry.get('id')
                st.rerun()
            if col2.button("🗑️ Delete", key=f"del_{entry.get('id', 0)}"):
                from database.queries import delete_entry
                if delete_entry(entry.get('id')):
                    st.success("Entry deleted")
                    st.rerun()
            if col3.button("📤 Export", key=f"exp_{entry.get('id', 0)}"):
                st.session_state['export_entry'] = entry
                st.rerun()

def render_entry_grid(entries: pd.DataFrame):
    """Renders entries in 3-column responsive grid"""
    if entries.empty:
        st.info("No entries found.")
        return
    
    cols = st.columns(3)
    for idx, (_, entry) in enumerate(entries.iterrows()):
        with cols[idx % 3]:
            render_entry_card(entry.to_dict())

def render_entry_table(entries: pd.DataFrame):
    """Renders entries as sortable st.dataframe"""
    if entries.empty:
        st.info("No entries found.")
        return
    
    # Select relevant columns for table
    display_cols = ['date', 'cafe_name', 'coffee_name', 'process', 'rating', 'sentiment_score']
    available = [c for c in display_cols if c in entries.columns]
    
    st.dataframe(
        entries[available].sort_values('date', ascending=False),
        use_container_width=True,
        hide_index=True
    )