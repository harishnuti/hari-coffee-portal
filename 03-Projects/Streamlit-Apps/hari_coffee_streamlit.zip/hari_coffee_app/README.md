# ☕ Hari's Coffee Archive 2026

Production-grade Streamlit application for tracking specialty coffee audits, bean inventory, goals, and journal entries.

## Features
- **Dual-mode database**: Local SQLite (full CRUD) + Streamlit Cloud (CSV + session_state)
- **10 pages**: Dashboard, New Entry (smart form), Archive (filters + cards/table), Brew Lab (recipe calculator), Origins (world map + profiles), Bean Tracker (5 tabs), Goals, Journal, Export Hub (CSV/Gemini/Social/QR), Settings
- **Smart entry form**: Auto city/grinder fill, ratio calculator, sentiment scoring, similar entries sidebar, Gemini/Instagram/CSV export on submit
- **9 interactive Plotly charts**: Process donut, origin bar, timeline, palate radar, price scatter, grinder bar, dose-yield scatter, world map, degassing gauge
- **Full CRUD** across 8 database tables (archive, beans, brew_sessions, wishlist, goals, journal, saved_recipes)
- **Export everything**: CSV/JSON, 31 Gemini prompts, Instagram captions, Twitter threads, Google Maps reviews, share cards, recipe cards

## Local Run
```bash
cd hari_coffee_app
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Cloud Deployment
1. Push `hari_coffee_app/` folder to GitHub
2. Connect repo at [share.streamlit.io](https://share.streamlit.io)
3. Main file: `app.py`
4. **Important for Cloud**: New entries are stored in session_state only. Use **Export Hub → Archive Export** to download updated CSV and commit back to GitHub to persist permanently.

## File Structure
```
hari_coffee_app/
├── app.py
├── requirements.txt
├── .streamlit/config.toml
├── data/
│   └── hari_coffee_master.csv (31 seed entries)
├── database/
│   ├── __init__.py
│   ├── connection.py (cloud detection)
│   ├── schema.py (8 tables)
│   ├── queries.py (50+ functions)
│   └── seed.py (CSV + 5 wishlist + 20 goals)
├── components/
│   ├── __init__.py
│   ├── charts.py (9 Plotly charts)
│   ├── entry_card.py
│   ├── entry_form.py (smart form)
│   └── exporters.py (all generators)
└── pages/
    ├── 01_📊_Dashboard.py
    ├── 02_✏️_New_Entry.py
    ├── 03_📚_Archive.py
    ├── 04_☕_Brew_Lab.py
    ├── 05_🌍_Origins.py
    ├── 06_🫘_Bean_Tracker.py
    ├── 07_🎯_Goals.py
    ├── 08_📝_Journal.py
    ├── 09_📤_Export_Hub.py
    └── 10_⚙️_Settings.py
```

## Dark Gold Theme
- Primary: #c9a84c (gold)
- Background: #0d0d0d
- Cards: #1a1a1a
- Playfair Display headings via Google Fonts CDN

## Pre-loaded Data
- 31 archive entries (Jan–May 2026, Singapore/Bali/Mumbai/JB)
- 5 wishlist items (Colombia Gesha, Sudan Rume, etc.)
- 20 H2 2026 goals across 5 categories

Built with precision. No placeholders. Every function fully implemented.
```

Now, create a ZIP of the entire app.