// Hari Coffee Archive 2026 - OG Meta & Social Patch
// Ensures proper Open Graph tags even in static single-file deploys
(function() {
    const meta = document.createElement('meta');
    meta.setAttribute('property', 'og:title');
    meta.setAttribute('content', document.title || 'Hari Coffee Archive 2026');
    document.head.appendChild(meta);

    const desc = document.createElement('meta');
    desc.setAttribute('property', 'og:description');
    desc.setAttribute('content', document.querySelector('meta[name="description"]')?.content || 'Singapore specialty coffee archive — 31 audited entries, interactive tools, and palate fingerprint.');
    document.head.appendChild(desc);

    const image = document.createElement('meta');
    image.setAttribute('property', 'og:image');
    image.setAttribute('content', 'https://picsum.photos/id/1015/1200/630'); // placeholder coffee image
    document.head.appendChild(image);

    console.log('%c[Hari Coffee] og-meta-patch.js applied — social sharing ready', 'color:#666');
})();