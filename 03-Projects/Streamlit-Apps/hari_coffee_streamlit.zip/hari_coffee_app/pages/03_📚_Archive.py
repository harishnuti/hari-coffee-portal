import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import get_all_entries, get_unique_cities, get_unique_varietals, get_unique_cafes, delete_entry, get_entry_by_id
from components.entry_card import render_entry_grid, render_entry_table, render_entry_card

st.set_page_config(page_title="Archive - Hari's Coffee Archive", layout="wide")

st.title("📚 Full Archive")

df = get_all_entries()

# FILTER SIDEBAR
with st.sidebar:
    st.header("🔍 Filters")
    
    search = st.text_input("🔍 Search (coffee, cafe, verdict)", key="archive_search")
    
    cities = get_unique_cities()
    city_filter = st.multiselect("City", cities, key="archive_city")
    
    processes = df['process'].dropna().unique().tolist() if not df.empty else ['Washed', 'Natural']
    process_filter = st.multiselect("Process", processes, key="archive_process")
    
    varietals = get_unique_varietals()
    varietal_filter = st.multiselect("Varietal", varietals, key="archive_varietal")
    
    cafes = get_unique_cafes()
    cafe_filter = st.multiselect("Cafe", cafes, key="archive_cafe")
    
    date_range = st.date_input("Date range", [], key="archive_date")
    
    rating_min = st.slider("Min Rating", 0, 5, 0, key="archive_rating")
    
    partial_toggle = st.checkbox("Include partial entries", value=True, key="archive_partial")
    
    if st.button("Clear All Filters", key="clear_filters"):
        st.session_state.archive_search = ""
        st.session_state.archive_city = []
        st.session_state.archive_process = []
        st.session_state.archive_varietal = []
        st.session_state.archive_cafe = []
        st.session_state.archive_rating = 0
        st.rerun()

# Apply filters
filtered_df = df.copy()

if search:
    mask = (
        filtered_df['coffee_name'].str.contains(search, case=False, na=False) |
        filtered_df['cafe_name'].str.contains(search, case=False, na=False) |
        filtered_df['your_verdict'].str.contains(search, case=False, na=False)
    )
    filtered_df = filtered_df[mask]

if city_filter:
    filtered_df = filtered_df[filtered_df['city'].isin(city_filter)]

if process_filter:
    filtered_df = filtered_df[filtered_df['process'].isin(process_filter)]

if varietal_filter:
    filtered_df = filtered_df[filtered_df['varietal'].isin(varietal_filter)]

if cafe_filter:
    filtered_df = filtered_df[filtered_df['cafe_name'].isin(cafe_filter)]

if len(date_range) == 2:
    filtered_df = filtered_df[
        (pd.to_datetime(filtered_df['date']) >= pd.to_datetime(date_range[0])) &
        (pd.to_datetime(filtered_df['date']) <= pd.to_datetime(date_range[1]))
    ]

if rating_min > 0:
    filtered_df = filtered_df[filtered_df['rating'] >= rating_min]

if not partial_toggle:
    filtered_df = filtered_df[filtered_df['is_partial'] == 0]

# VIEW TOGGLE
st.markdown(f"**Showing {len(filtered_df)} of {len(df)} entries**")

view = st.radio("View Mode", ["🃏 Cards", "📋 Table", "📝 Compact"], horizontal=True, key="archive_view")

if view == "🃏 Cards":
    render_entry_grid(filtered_df)
elif view == "📋 Table":
    render_entry_table(filtered_df)
else:
    # Compact view
    for _, entry in filtered_df.iterrows():
        with st.container():
            col1, col2, col3 = st.columns([3, 2, 1])
            col1.write(f"**{entry.get('coffee_name', '')}** @ {entry.get('cafe_name', '')}")
            col2.write(f"{entry.get('date', '')} • {entry.get('process', '')}")
            col3.write(f"{'★' * int(entry.get('rating', 0))}")
            if st.button("View Details", key=f"view_{entry.get('id')}"):
                st.session_state['selected_entry'] = entry.to_dict()
                st.rerun()

# Entry detail modal
if 'selected_entry' in st.session_state:
    entry = st.session_state['selected_entry']
    with st.expander(f"📖 {entry.get('coffee_name')} - Full Details", expanded=True):
        render_entry_card(entry, expanded=True)
        if st.button("Close Details"):
            del st.session_state['selected_entry']
            st.rerun()