// og-meta-patch.js - Ensures proper meta for sharing and print
document.addEventListener('DOMContentLoaded', () => {
  // Add or update meta tags if missing
  const metaAuthor = document.createElement('meta');
  metaAuthor.name = 'author';
  metaAuthor.content = 'Hari, Coffee Archivist';
  document.head.appendChild(metaAuthor);

  const metaDesc = document.createElement('meta');
  metaDesc.name = 'description';
  metaDesc.content = 'Hari Coffee Archive 2026 — 31 specialty coffee audits from Singapore and beyond. Interactive tools for sensory vocabulary, varietals, harvest planning, brew recipes, timeline, and cafe comparison.';
  document.head.appendChild(metaDesc);

  // Open Graph
  const ogTitle = document.createElement('meta');
  ogTitle.property = 'og:title';
  ogTitle.content = document.title || 'Hari Coffee Archive 2026';
  document.head.appendChild(ogTitle);

  const ogDesc = document.createElement('meta');
  ogDesc.property = 'og:description';
  ogDesc.content = 'Interactive archive of 31 specialty coffee tastings. Explore sensory terms, varietal genetics, seasonal availability, printable recipes, audit timeline, and cafe ratings.';
  document.head.appendChild(ogDesc);

  const ogImage = document.createElement('meta');
  ogImage.property = 'og:image';
  ogImage.content = 'https://picsum.photos/id/1015/1200/630'; // placeholder coffee image
  document.head.appendChild(ogImage);

  // Print hint
  console.log('%c[Hari Archive] Print-ready with @media print styles active', 'color:#c9a84c');
});
