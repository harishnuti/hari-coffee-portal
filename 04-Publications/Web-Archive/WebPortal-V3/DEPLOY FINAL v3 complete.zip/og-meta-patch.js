// og-meta-patch.js
// Injects Open Graph meta tags into every page for beautiful link previews
// (WhatsApp, Twitter, Facebook, LinkedIn, Discord, etc.)

(function() {
  const title = "Hari's Coffee Archive 2026";
  const description = "31 specialty coffee audits across 4 cities. Interactive archive, Singapore guide, science encyclopedia, brew calculator & social content generator.";
  const url = window.location.href;
  
  // Generate simple elegant SVG og-image (coffee bean + gold text)
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
      <rect width="1200" height="630" fill="#0d0d0d"/>
      <ellipse cx="600" cy="280" rx="180" ry="240" fill="#c9a84c" transform="rotate(-12 600 280)"/>
      <path d="M480 160 Q600 260 720 160" stroke="#8a6f2e" stroke-width="18" stroke-linecap="round"/>
      <text x="600" y="420" font-family="Playfair Display, Georgia, serif" font-size="72" fill="#c9a84c" text-anchor="middle" font-weight="700">Hari's Coffee Archive</text>
      <text x="600" y="480" font-family="Inter, system-ui" font-size="32" fill="#f5f5f5" text-anchor="middle">2026 • 31 Audits • 4 Cities</text>
      <text x="600" y="540" font-family="Inter, system-ui" font-size="24" fill="#888" text-anchor="middle">Specialty Coffee • Singapore • Bali • JB • Mumbai</text>
    </svg>
  `;
  const ogImage = 'data:image/svg+xml;base64,' + btoa(svg);

  function addMeta(property, content) {
    let meta = document.createElement('meta');
    meta.setAttribute('property', property);
    meta.setAttribute('content', content);
    document.head.appendChild(meta);
  }

  // Add Open Graph tags
  addMeta('og:title', title);
  addMeta('og:description', description);
  addMeta('og:image', ogImage);
  addMeta('og:url', url);
  addMeta('og:type', 'website');
  addMeta('og:site_name', "Hari's Coffee Archive");

  // Twitter Card tags
  addMeta('twitter:card', 'summary_large_image');
  addMeta('twitter:title', title);
  addMeta('twitter:description', description);
  addMeta('twitter:image', ogImage);

  console.log('%c[OG Meta] Open Graph tags injected successfully for social previews.', 'color:#c9a84c');
})();
