# API Reference — Hari's Coffee Archive 2026

**Version:** 1.0.1  
**Total Public Functions:** 60+

---

## SECTION 1 — components/exporters.py

### generate_csv_line(entry: dict) → str
**Input:** Dictionary containing all 17 archive fields (date, city, cafe_name, coffee_name, varietal, process, roast_level, brew_method, dose_g, yield_g, ratio, bloom, grinder, price_local, official_notes, your_verdict, technical_enrichment)

**Output:** Properly quoted, comma-separated CSV line matching the exact master format.

**Example:**
```python
entry = {"date": "2026-05-19", "coffee_name": "Ecuador La Papaya", ...}
line = generate_csv_line(entry)
# Returns: 2026-05-19,"Singapore","Pocket by Flip (Flip Coffee Roasters)",...
```

### generate_gemini_prompt(entry: dict) → str
**Input:** Full archive entry dict

**Output:** Complete 5-section Gemini infographic prompt ready to paste into Gemini.

**Structure:**
- TITLE + SUBTITLE
- SECTION 1 — THE BEAN
- SECTION 2 — BREW PARAMETERS
- SECTION 3 — TASTING NOTES
- SECTION 4 — TECHNICAL ENRICHMENT
- SECTION 5 — METRICS
- STYLE SPEC (dark gold cinematic)

### generate_instagram_caption(entry: dict, tone: str = 'balanced') → str
**tone options:** `'technical' | 'balanced' | 'accessible'`

**Output:** 150–200 word Instagram caption in Hari's voice + 15 relevant hashtags.

### generate_twitter_thread(entry: dict) → list[str]
**Output:** List of exactly 8 tweets (each ≤ 280 characters) forming a complete thread.

### generate_maps_review(entry: dict, variant: str = 'accessible') → str
**variant options:** `'technical' | 'accessible' | 'short'`

**Output:** Ready-to-post Google Maps review text (3 variants available).

### generate_share_card(entry: dict) → str
**Output:** Beautiful bordered text card suitable for WhatsApp / Telegram / Signal.

---

## SECTION 2 — components/charts.py (10 Functions)

All functions return `plotly.graph_objects.Figure` and use the consistent dark gold theme.

| Function | Input | Visualisation |
|----------|-------|---------------|
| `render_process_donut(df)` | pd.DataFrame with 'process' column | Donut chart of process distribution |
| `render_origin_bar(df)` | pd.DataFrame | Horizontal bar of entries by origin |
| `render_monthly_timeline(df)` | pd.DataFrame with 'date' | Line chart Jan–May 2026 |
| `render_palate_radar(scores: dict)` | dict with Acid/Body/Sweetness/Clarity/Complexity | Spider/radar chart |
| `render_price_scatter(df)` | pd.DataFrame with price_local + rating | Scatter: price vs rating by city |
| `render_grinder_bar(df)` | pd.DataFrame with 'grinder' | Horizontal bar of grinder usage |
| `render_top_entries_bar(df)` | pd.DataFrame with sentiment_score | Bar chart of top 8 entries |
| `render_dose_yield_scatter(df)` | pd.DataFrame with dose_g + yield_g | Scatter colored by brew method |
| `render_world_map(df)` | pd.DataFrame | Interactive world map with origin markers |
| `render_degassing_gauge(roast_date: str)` | ISO date string | Gauge showing degassing window status (0–45 days) |

---

## SECTION 3 — database/queries.py (44+ Functions)

### Archive CRUD
- `get_all_entries(filters=None) → pd.DataFrame`
- `get_entry_by_id(entry_id) → dict`
- `insert_entry(data: dict) → int`
- `update_entry(entry_id: int, data: dict) → bool`
- `delete_entry(entry_id: int) → bool`
- `get_entries_count() → int`
- `search_entries(query: str) → pd.DataFrame`

### Dropdown / Smart Form Helpers
- `get_unique_cafes() → list`
- `get_unique_cities() → list`
- `get_unique_varietals() → list`
- `get_unique_grinders() → list`
- `get_cafe_city_map() → dict`
- `get_cafe_grinder_map() → dict`
- `get_entries_by_cafe(cafe: str) → pd.DataFrame`

### Analytics
- `get_process_counts() → pd.DataFrame`
- `get_origin_counts() → pd.DataFrame`
- `get_entries_by_month() → pd.DataFrame`
- `get_top_entries(n=5) → pd.DataFrame`
- `get_palate_scores() → dict`
- `get_grinder_counts() → pd.DataFrame`

### Beans
- `get_all_beans() → pd.DataFrame`
- `insert_bean(data: dict) → int`
- `update_bean_weight(bean_id: int, new_weight: int) → bool`
- `finish_bean(bean_id: int, rating: int) → bool`

### Brew Sessions
- `get_all_brew_sessions() → pd.DataFrame`
- `insert_brew_session(data: dict) → int`

### Wishlist
- `get_wishlist() → pd.DataFrame`
- `insert_wishlist_item(data: dict) → int`
- `mark_purchased(item_id: int) → bool`
- `delete_wishlist_item(item_id: int) → bool`

### Goals
- `get_all_goals() → pd.DataFrame`
- `insert_goal(data: dict) → int`
- `complete_goal(goal_id: int) → bool`
- `get_goals_by_category() → dict`

### Journal
- `get_all_journal_entries() → pd.DataFrame`
- `insert_journal_entry(data: dict) → int`
- `update_journal_entry(entry_id: int, data: dict) → bool`
- `delete_journal_entry(entry_id: int) → bool`

### Saved Recipes
- `get_saved_recipes() → pd.DataFrame`
- `insert_saved_recipe(data: dict) → int`
- `delete_saved_recipe(recipe_id: int) → bool`

### Cloud Mode Helpers
- `get_entries_from_state() → pd.DataFrame`
- `add_entry_to_state(data: dict)`
- `get_all_entries_merged() → pd.DataFrame`

### Sentiment
- `calculate_sentiment(verdict: str) → float` (also available from seed.py for backward compatibility)

---

## Usage Examples

```python
from database.queries import get_all_entries, calculate_sentiment, insert_entry

# Get filtered data
df = get_all_entries({'process': 'Washed', 'city': ['Singapore']})

# Score a verdict
score = calculate_sentiment("This is the best Geisha I've ever had — clean, floral, elegant.")

# Insert new entry
new_id = insert_entry({
    'date': '2026-05-20',
    'cafe_name': 'Nylon Coffee Roasters',
    'coffee_name': 'Test Entry',
    'your_verdict': 'Excellent clarity and sweetness.',
    ...
})
```

All functions are fully documented with type hints and handle both local SQLite and cloud session_state modes transparently.