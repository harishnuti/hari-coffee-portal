import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import get_all_entries
from components.charts import render_world_map
from components.entry_card import render_entry_table

st.set_page_config(page_title="Origins - Hari's Coffee Archive", layout="wide")

st.title("🌍 Origin Deep Map")

df = get_all_entries()

# World Map
st.plotly_chart(render_world_map(df), use_container_width=True)

# Origin selector
ORIGINS = ['Colombia', 'Brazil', 'Ethiopia', 'Panama', 'Peru', 'Ecuador', 'Kenya', 'Nicaragua', 'Honduras', 'El Salvador', 'Indonesia', 'India']

selected = st.selectbox("Explore Origin", ORIGINS)

# Hardcoded origin profiles
ORIGIN_PROFILES = {
    'Colombia': {
        'altitude': "1,200 - 2,200 MASL",
        'soil': "Volcanic, rich in minerals",
        'climate': "Tropical highland, consistent rainfall",
        'harvest': "Oct - Feb (main), May - Aug (secondary)",
        'primary_acid': "Citric + Malic balance",
        'body_tendency': "Medium to full, syrupy when natural"
    },
    'Ethiopia': {
        'altitude': "1,800 - 2,600 MASL",
        'soil': "Red-brown clay, high organic",
        'climate': "Highland temperate, long dry season",
        'harvest': "Oct - Dec (main)",
        'primary_acid': "Citric dominant, bright",
        'body_tendency': "Light to medium, tea-like"
    },
    'Panama': {
        'altitude': "1,400 - 1,900 MASL",
        'soil': "Volcanic loam",
        'climate': "Tropical, distinct wet/dry seasons",
        'harvest': "Dec - Mar",
        'primary_acid': "Citric + Tartaric",
        'body_tendency': "Elegant, structured"
    },
    'Peru': {
        'altitude': "1,500 - 2,300 MASL",
        'soil': "Andean volcanic",
        'climate': "Highland, misty",
        'harvest': "May - Sep",
        'primary_acid': "Citric + Malic",
        'body_tendency': "Medium, clean"
    },
    'Brazil': {
        'altitude': "800 - 1,400 MASL",
        'soil': "Red latosol, fertile",
        'climate': "Tropical savanna",
        'harvest': "May - Sep",
        'primary_acid': "Malic dominant in naturals",
        'body_tendency': "Full, chocolatey"
    },
    'Kenya': {
        'altitude': "1,500 - 2,100 MASL",
        'soil': "Volcanic red soil",
        'climate': "Highland equatorial",
        'harvest': "Oct - Dec, Apr - Jun",
        'primary_acid': "Citric + Phosphoric",
        'body_tendency': "Juicy, wine-like"
    },
    'Ecuador': {
        'altitude': "1,800 - 2,400 MASL (Loja highest)",
        'soil': "Volcanic, mineral-rich",
        'climate': "Andean highland",
        'harvest': "May - Aug",
        'primary_acid': "Citric + Malic",
        'body_tendency': "Elegant, terpene-forward"
    },
    'Indonesia': {
        'altitude': "1,000 - 1,800 MASL",
        'soil': "Volcanic, high acidity",
        'climate': "Tropical rainforest",
        'harvest': "Year-round (peak May - Oct)",
        'primary_acid': "Malic + Citric",
        'body_tendency': "Heavy, earthy (wet-hulled)"
    },
    'India': {
        'altitude': "800 - 1,600 MASL",
        'soil': "Laterite, red soil",
        'climate': "Tropical monsoon",
        'harvest': "Nov - Feb",
        'primary_acid': "Malic",
        'body_tendency': "Full, spiced"
    },
    'Nicaragua': {
        'altitude': "1,000 - 1,600 MASL",
        'soil': "Volcanic",
        'climate': "Tropical highland",
        'harvest': "Nov - Feb",
        'primary_acid': "Citric",
        'body_tendency': "Medium, clean"
    },
    'Honduras': {
        'altitude': "1,100 - 1,700 MASL",
        'soil': "Volcanic",
        'climate': "Tropical highland",
        'harvest': "Nov - Mar",
        'primary_acid': "Citric + Malic",
        'body_tendency': "Medium-full"
    },
    'El Salvador': {
        'altitude': "1,200 - 1,800 MASL",
        'soil': "Volcanic",
        'climate': "Tropical highland",
        'harvest': "Nov - Feb",
        'primary_acid': "Citric",
        'body_tendency': "Elegant, bright"
    }
}

if selected in ORIGIN_PROFILES:
    profile = ORIGIN_PROFILES[selected]
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.subheader("🗺️ Terroir Profile")
        st.write(f"**Altitude:** {profile['altitude']}")
        st.write(f"**Soil:** {profile['soil']}")
        st.write(f"**Climate:** {profile['climate']}")
        st.write(f"**Harvest Window:** {profile['harvest']}")
    
    with col2:
        st.subheader("📊 Archive Data")
        origin_entries = df[df['coffee_name'].str.contains(selected, case=False, na=False)] if not df.empty else pd.DataFrame()
        st.metric("Entries", len(origin_entries))
        if not origin_entries.empty:
            top = origin_entries.iloc[0]
            st.write(f"**Top Entry:** {top.get('coffee_name', '')}")
            st.write(f"**Avg Sentiment:** {origin_entries['sentiment_score'].mean():.1f}/10")
    
    with col3:
        st.subheader("⚗️ Acid Chemistry")
        st.write(f"**Primary Acid:** {profile['primary_acid']}")
        st.write(f"**Body Tendency:** {profile['body_tendency']}")
        st.write(f"**Thermal Shift:** Recommended 90→75→92°C for high-altitude Geishas")
    
    # Entries table
    st.subheader(f"📋 All {selected} Entries in Archive")
    if not origin_entries.empty:
        render_entry_table(origin_entries)
    else:
        st.info(f"No specific {selected} entries found. Try broadening search.")