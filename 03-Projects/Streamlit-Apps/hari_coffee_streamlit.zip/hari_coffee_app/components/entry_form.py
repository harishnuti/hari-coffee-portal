import streamlit as st
import pandas as pd
from datetime import date, datetime
from database.queries import (
    get_unique_cafes, get_unique_cities, get_cafe_city_map, 
    get_cafe_grinder_map, get_entries_by_cafe, insert_entry, update_entry,
    calculate_sentiment  # Will import from seed
)
from database.seed import calculate_sentiment as calc_sentiment

# DROPDOWN CONSTANTS
CITIES = ['Singapore', 'Johor Bahru', 'Ubud, Bali', 'Mumbai', 'Other (specify)']

VARIETALS = ['Geisha', 'Gesha', 'Sudan Rume', 'Wush Wush', 'Heirloom', 'Arara', 
             'Typica', 'Typica Mejorado', 'Marshell', 'Hybrid Laurina', 'Parainema',
             'Catucai 24/137', 'Castillo', 'Pacamara', 'Sidra', 'Bourbon', 
             'Local Varietals', 'Other (specify)']

PROCESSES = ['Washed', 'Natural', 'Red Honey', 'Extended Fermentation Honey', 
             'Anaerobic Natural', 'Anaerobic Washed', 'Double Anaerobic',
             'Washed Co-ferment', 'Co-ferment', 'Natural Fermentation', 
             'Semi-Washed / Wet-Hulled', 'Experimental Anaerobic', 'Multi-stage Anaerobic']

ROAST_LEVELS = ['Light', 'Light-Medium', 'Medium', 'Medium-Dark', 'Espresso Roast', 
                'Filter Roast', 'Unknown']

BREW_METHODS = ['V60 Pour-over', 'Flat-Bottom (Hario Alpha)', 'Flatbed Dripper', 
                'Hario Switch', 'xBloom Automated', 'Origami Conical', 
                'Pour-over (generic)', 'Espresso', 'Flat White', 'Batch Brew',
                'Iced Pour-over', 'Flash-Chill']

GRINDERS = ['Mahlkönig EK43 (98mm flat)', 'Mahlkönig EK43S (98mm flat)',
            'Mahlkönig CORE (54mm flat)', 'Mahlkönig EK Omnia',
            'Timemore Sculptor 078 (SSP 78mm)', 'Option-O Lagom P64 (SSP 64mm)',
            'Comandante C40', 'xBloom Integrated', '120mm Hybrid Burr', 
            'Other (specify)']

OFFICIAL_NOTE_TAGS = [
    'Jasmine', 'Rose', 'Lavender', 'Hibiscus', 'Apricot', 'Peach', 'Plum', 'Nectarine',
    'Mango', 'Lemon', 'Lime', 'Orange', 'Grapefruit', 'Apple', 'Raspberry', 'Strawberry',
    'Blackcurrant', 'Rooibos', 'Earl Grey', 'White Tea', 'Oolong', 'Caramel', 'Toffee',
    'Chocolate', 'Hazelnut', 'Brown Sugar', 'Honey', 'Cane Sugar', 'Vanilla',
    'Mandarin Candy', 'Kiwi', 'Bergamot', 'Thyme', 'Red Apple', 'Black Cherry'
]

PROCESS_DESCRIPTIONS = {
    'Washed': "Fruit removed before drying. Clarity-forward, bright acidity.",
    'Natural': "Dried with fruit intact. Sweet, fruity, heavy body.",
    'Red Honey': "Partial fruit removal (red mucilage). Balanced sweetness + body.",
    'Extended Fermentation Honey': "Prolonged fermentation + honey process. Complex jammy notes.",
    'Anaerobic Natural': "Fermented without oxygen, dried with fruit. Intense esters, savory depth.",
    'Anaerobic Washed': "Anaerobic fermentation then washed. Complex + clean finish.",
    'Double Anaerobic': "Two-stage anaerobic fermentation. Maximum complexity, heavy body.",
    'Washed Co-ferment': "Co-fermentation with yeast/bacteria then washed. Layered aromatics.",
    'Co-ferment': "Co-fermentation with fruit/yeast. Bold, experimental profile.",
    'Natural Fermentation': "Extended natural fermentation. Deep fruit, wine-like.",
    'Semi-Washed / Wet-Hulled': "Partial washing + wet-hulling. Earthy, full body (Indonesian).",
    'Experimental Anaerobic': "Custom anaerobic protocol. Unique fermentation-driven identity.",
    'Multi-stage Anaerobic': "Multiple anaerobic phases. Highly complex, layered esters."
}

def render_entry_form(existing_entry=None) -> dict:
    """
    Renders the full smart entry form.
    Returns dict of all field values on submit, or None if not submitted.
    """
    st.markdown("---")
    st.subheader("✏️ Audit Entry Form")
    
    # Initialize form data
    if existing_entry:
        form_data = existing_entry.copy()
    else:
        form_data = {}
    
    result = None
    
    # ========== SECTION 1 — WHO/WHERE/WHEN ==========
    st.markdown("### 📍 Section 1: Who / Where / When")
    
    col1, col2 = st.columns(2)
    
    with col1:
        default_date = datetime.strptime(form_data.get('date', '2026-05-20'), '%Y-%m-%d').date() if form_data.get('date') else date.today()
        form_data['date'] = str(st.date_input("Date", value=default_date, key="form_date"))
    
    with col2:
        current_city = form_data.get('city', 'Singapore')
        city_options = CITIES.copy()
        if current_city not in city_options:
            city_options.append(current_city)
        city_sel = st.selectbox("City", city_options, 
                                index=city_options.index(current_city) if current_city in city_options else 0,
                                key="form_city")
        if city_sel == 'Other (specify)':
            form_data['city'] = st.text_input("Specify City", value=form_data.get('city', ''), key="form_city_other")
        else:
            form_data['city'] = city_sel
    
    col1, col2 = st.columns(2)
    
    with col1:
        cafes = get_unique_cafes()
        current_cafe = form_data.get('cafe_name', '')
        cafe_options = ['Add new cafe...'] + cafes
        if current_cafe and current_cafe not in cafe_options:
            cafe_options.insert(1, current_cafe)
        
        cafe_sel = st.selectbox("Cafe Name", cafe_options, 
                                index=cafe_options.index(current_cafe) if current_cafe in cafe_options else 0,
                                key="form_cafe")
        
        if cafe_sel == 'Add new cafe...':
            form_data['cafe_name'] = st.text_input("New Cafe Name", key="form_new_cafe")
        else:
            form_data['cafe_name'] = cafe_sel
    
    with col2:
        # Auto-fill city from cafe history
        cafe_city_map = get_cafe_city_map()
        if form_data.get('cafe_name') in cafe_city_map:
            auto_city = cafe_city_map[form_data['cafe_name']]
            if auto_city != form_data.get('city'):
                st.info(f"📍 Auto-detected: **{auto_city}** (from previous visits)")
                form_data['city'] = auto_city
        
        # Show previous visits count
        if form_data.get('cafe_name'):
            prev_entries = get_entries_by_cafe(form_data['cafe_name'])
            st.caption(f"Previous visits to this cafe: **{len(prev_entries)}**")
    
    # Show last grinder used
    grinder_map = get_cafe_grinder_map()
    if form_data.get('cafe_name') in grinder_map:
        st.caption(f"🔧 Last grinder used here: **{grinder_map[form_data['cafe_name']]}**")
    
    # ========== SECTION 2 — THE BEAN ==========
    st.markdown("### 🫘 Section 2: The Bean")
    
    col1, col2 = st.columns(2)
    
    with col1:
        form_data['coffee_name'] = st.text_input("Coffee Name", 
            value=form_data.get('coffee_name', ''), 
            placeholder="e.g. Panama Corpachi Geisha",
            key="form_coffee_name")
    
    with col2:
        current_var = form_data.get('varietal', '')
        var_options = VARIETALS.copy()
        if current_var and current_var not in var_options:
            var_options.insert(0, current_var)
        var_sel = st.selectbox("Varietal", var_options, 
                               index=var_options.index(current_var) if current_var in var_options else 0,
                               key="form_varietal")
        if var_sel == 'Other (specify)':
            form_data['varietal'] = st.text_input("Specify Varietal", key="form_var_other")
        else:
            form_data['varietal'] = var_sel
    
    col1, col2 = st.columns(2)
    
    with col1:
        current_proc = form_data.get('process', 'Washed')
        proc_sel = st.selectbox("Process", PROCESSES, 
                                index=PROCESSES.index(current_proc) if current_proc in PROCESSES else 0,
                                key="form_process")
        form_data['process'] = proc_sel
        if proc_sel in PROCESS_DESCRIPTIONS:
            st.caption(f"ℹ️ {PROCESS_DESCRIPTIONS[proc_sel]}")
    
    with col2:
        current_roast = form_data.get('roast_level', 'Light')
        form_data['roast_level'] = st.radio("Roast Level", ROAST_LEVELS, 
                                            index=ROAST_LEVELS.index(current_roast) if current_roast in ROAST_LEVELS else 0,
                                            horizontal=True, key="form_roast")
    
    # ========== SECTION 3 — BREW PARAMETERS ==========
    st.markdown("### ⚗️ Section 3: Brew Parameters")
    
    col1, col2 = st.columns(2)
    
    with col1:
        current_brew = form_data.get('brew_method', 'V60 Pour-over')
        form_data['brew_method'] = st.selectbox("Brew Method", BREW_METHODS,
                                                index=BREW_METHODS.index(current_brew) if current_brew in BREW_METHODS else 0,
                                                key="form_brew")
    
    with col2:
        current_grind = form_data.get('grinder', '')
        grind_options = GRINDERS.copy()
        if current_grind and current_grind not in grind_options:
            grind_options.insert(0, current_grind)
        grind_sel = st.selectbox("Grinder", grind_options,
                                 index=grind_options.index(current_grind) if current_grind in grind_options else 0,
                                 key="form_grinder")
        if grind_sel == 'Other (specify)':
            form_data['grinder'] = st.text_input("Specify Grinder", key="form_grind_other")
        else:
            form_data['grinder'] = grind_sel
    
    # Dose / Yield / Ratio row
    col1, col2, col3 = st.columns(3)
    
    with col1:
        form_data['dose_g'] = st.number_input("Dose (g)", min_value=5.0, max_value=30.0, 
                                              value=float(form_data.get('dose_g', 15.0)), step=0.5, key="form_dose")
    
    with col2:
        form_data['yield_g'] = st.number_input("Yield (g)", min_value=50.0, max_value=400.0,
                                               value=float(form_data.get('yield_g', 225.0)), step=5.0, key="form_yield")
    
    with col3:
        if form_data.get('dose_g') and form_data.get('yield_g') and form_data['dose_g'] > 0:
            ratio_val = round(form_data['yield_g'] / form_data['dose_g'], 1)
            form_data['ratio'] = f"1:{ratio_val}"
        else:
            form_data['ratio'] = form_data.get('ratio', '1:15')
        st.text_input("Ratio (auto)", value=form_data['ratio'], disabled=True, key="form_ratio")
    
    col1, col2 = st.columns(2)
    
    with col1:
        form_data['bloom'] = st.text_input("Bloom (g / sec)", 
            value=form_data.get('bloom', '30g / 30s'),
            placeholder="e.g. 30g / 30sec",
            key="form_bloom")
    
    with col2:
        form_data['brew_temp'] = st.text_input("Brew Temperature", 
            value=form_data.get('brew_temp', '92°C'),
            placeholder="e.g. 92°C or 92→75→92°C",
            key="form_temp")
    
    # ========== SECTION 4 — PRICE ==========
    st.markdown("### 💰 Section 4: Price")
    
    price_col, curr_col = st.columns([3, 1])
    
    with price_col:
        current_price = form_data.get('price_local', '')
        # Try to extract number
        price_num = 0.0
        if current_price:
            try:
                price_num = float(''.join(filter(lambda x: x.isdigit() or x == '.', str(current_price))))
            except:
                pass
        form_data['price_value'] = st.number_input("Price", min_value=0.0, step=0.5, value=price_num, key="form_price")
    
    with curr_col:
        currencies = ['SGD', 'IDR', 'INR', 'MYR', 'JPY', 'USD']
        current_curr = 'SGD'
        if current_price and any(c in str(current_price) for c in currencies):
            for c in currencies:
                if c in str(current_price):
                    current_curr = c
                    break
        form_data['currency'] = st.selectbox("Currency", currencies, 
                                             index=currencies.index(current_curr), key="form_curr")
    
    form_data['price_local'] = f"{form_data['currency']} {form_data['price_value']:.2f}"
    
    # ========== SECTION 5 — TASTING NOTES ==========
    st.markdown("### 👅 Section 5: Tasting Notes")
    
    st.subheader("Official Roaster Notes")
    current_notes = form_data.get('official_notes', '')
    selected_tags = []
    if current_notes:
        selected_tags = [t.strip() for t in str(current_notes).split(',') if t.strip()]
    
    selected = st.multiselect("Select tags", OFFICIAL_NOTE_TAGS, 
                              default=selected_tags, key="form_tags")
    
    custom_notes = st.text_input("Additional notes (comma-separated)", 
                                  value='', key="form_custom_notes")
    
    all_notes = selected + [n.strip() for n in custom_notes.split(',') if n.strip()]
    form_data['official_notes'] = ', '.join(all_notes)
    
    st.subheader("Your Verdict")
    form_data['your_verdict'] = st.text_area(
        "Describe what you experienced...",
        value=form_data.get('your_verdict', ''),
        height=180,
        key="form_verdict"
    )
    
    # Verdict stats
    col1, col2, col3 = st.columns(3)
    verdict_text = form_data.get('your_verdict', '')
    word_count = len(verdict_text.split()) if verdict_text else 0
    
    with col1:
        st.caption(f"📝 Words: **{word_count}**")
    with col2:
        st.caption(f"⏱️ ~{max(1, word_count // 200 + 1)} min read")
    with col3:
        sentiment = calc_sentiment(verdict_text)
        form_data['sentiment_score'] = sentiment
        st.caption(f"💫 Sentiment: **{sentiment:.1f}/10**")
    
    # Similar entries sidebar
    if form_data.get('cafe_name'):
        with st.expander(f"📜 Previous visits to {form_data['cafe_name']}"):
            prev = get_entries_by_cafe(form_data['cafe_name']).head(3)
            for _, p in prev.iterrows():
                st.caption(f"• {p.get('coffee_name', '')}: {str(p.get('your_verdict', ''))[:60]}...")
    
    st.subheader("Technical Enrichment")
    form_data['technical_enrichment'] = st.text_area(
        "Hardware + ratio + process chemistry explanation",
        value=form_data.get('technical_enrichment', ''),
        height=120,
        key="form_tech"
    )
    
    # ========== SECTION 6 — METADATA ==========
    st.markdown("### 📊 Section 6: Metadata")
    
    col1, col2 = st.columns(2)
    
    with col1:
        current_rating = int(form_data.get('rating', 4))
        form_data['rating'] = st.select_slider(
            "Overall Rating",
            options=[1, 2, 3, 4, 5],
            value=current_rating,
            format_func=lambda x: "★" * x + "☆" * (5 - x),
            key="form_rating"
        )
    
    with col2:
        form_data['is_partial'] = st.checkbox("Partial entry (limited data)", 
                                              value=bool(form_data.get('is_partial', 0)),
                                              key="form_partial")
    
    # ========== SECTION 7 — SUBMIT ==========
    st.markdown("---")
    st.subheader("✅ Submit Entry")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("💾 Save Draft", type="secondary", key="btn_draft"):
            form_data['is_draft'] = 1
            if existing_entry and existing_entry.get('id'):
                success = update_entry(existing_entry['id'], form_data)
            else:
                new_id = insert_entry(form_data)
                success = new_id > 0
            if success:
                st.success("✅ Draft saved successfully!")
                st.balloons()
            else:
                st.error("Failed to save draft")
    
    with col2:
        if st.button("✅ Submit Entry", type="primary", key="btn_submit"):
            # Validation
            errors = []
            if not form_data.get('date'):
                errors.append("Date is required")
            if not form_data.get('cafe_name'):
                errors.append("Cafe name is required")
            if not form_data.get('coffee_name'):
                errors.append("Coffee name is required")
            if not form_data.get('your_verdict'):
                errors.append("Your verdict is required")
            
            if errors:
                for e in errors:
                    st.error(f"❌ {e}")
            else:
                form_data['is_draft'] = 0
                form_data['sentiment_score'] = calc_sentiment(form_data.get('your_verdict', ''))
                
                if existing_entry and existing_entry.get('id'):
                    success = update_entry(existing_entry['id'], form_data)
                    new_id = existing_entry['id']
                else:
                    new_id = insert_entry(form_data)
                    success = new_id > 0
                
                if success:
                    st.success(f"✅ Entry #{new_id} saved successfully!")
                    st.balloons()
                    
                    # Show post-submit options
                    with st.expander("📋 CSV Line (copy to master)"):
                        csv_line = generate_csv_line(form_data)
                        st.code(csv_line, language="csv")
                    
                    with st.expander("🖼️ Gemini Infographic Prompt"):
                        gemini_prompt = generate_gemini_prompt(form_data)
                        st.code(gemini_prompt, language="text")
                    
                    with st.expander("📱 Instagram Caption"):
                        ig_caption = generate_instagram_caption(form_data)
                        st.text_area("Caption", ig_caption, height=200)
                    
                    result = form_data
                else:
                    st.error("Failed to save entry. Check logs.")
    
    return result

def generate_csv_line(entry: dict) -> str:
    """Generates exact 17-column CSV line matching master format"""
    fields = [
        entry.get('date', ''),
        entry.get('city', ''),
        entry.get('cafe_name', ''),
        entry.get('coffee_name', ''),
        entry.get('varietal', ''),
        entry.get('process', ''),
        entry.get('roast_level', ''),
        entry.get('brew_method', ''),
        str(entry.get('dose_g', '')),
        str(entry.get('yield_g', '')),
        entry.get('ratio', ''),
        entry.get('bloom', ''),
        entry.get('grinder', ''),
        entry.get('price_local', ''),
        entry.get('official_notes', ''),
        entry.get('your_verdict', ''),
        entry.get('technical_enrichment', '')
    ]
    # Quote fields with commas
    quoted = []
    for f in fields:
        f = str(f).replace('"', '""')
        if ',' in f or '"' in f:
            quoted.append(f'"{f}"')
        else:
            quoted.append(f)
    return ','.join(quoted)

def generate_gemini_prompt(entry: dict) -> str:
    """Generates Gemini infographic prompt"""
    coffee = entry.get('coffee_name', 'Specialty Coffee')
    cafe = entry.get('cafe_name', 'Specialty Cafe')
    verdict = entry.get('your_verdict', 'Exceptional cup')
    
    prompt = f"""Create a cinematic 16:9 dark-amber aesthetic infographic for a specialty coffee archive entry.

TITLE: "{coffee} @ {cafe}"

SUBTITLE: {entry.get('date', '')} • {entry.get('city', '')} • {entry.get('process', '')} Process

SECTION 1 — THE BEAN
• Origin: {entry.get('city', 'Unknown')}
• Varietal: {entry.get('varietal', 'Unknown')}
• Process: {entry.get('process', 'Unknown')}
• Roast: {entry.get('roast_level', 'Unknown')}

SECTION 2 — BREW PARAMETERS
• Method: {entry.get('brew_method', 'Unknown')}
• Grinder: {entry.get('grinder', 'Unknown')}
• Ratio: {entry.get('ratio', '1:15')}
• Temp: {entry.get('brew_temp', '92°C')}
• Dose → Yield: {entry.get('dose_g', 15)}g → {entry.get('yield_g', 225)}g

SECTION 3 — TASTING NOTES
Official: {entry.get('official_notes', 'N/A')}
Verdict: {verdict[:200]}

SECTION 4 — TECHNICAL
{entry.get('technical_enrichment', 'Precision extraction with controlled thermal profiling.')}

SECTION 5 — SENTIMENT
Score: {entry.get('sentiment_score', 8.5)}/10 • Rating: {entry.get('rating', 4)}★

STYLE: Dark coffee background (#0d0d0d), gold accents (#c9a84c), elegant serif typography, subtle steam effects, professional specialty coffee magazine aesthetic. High contrast, cinematic lighting."""

    return prompt

def generate_instagram_caption(entry: dict, tone='balanced') -> str:
    """Generates Instagram caption in Hari's voice"""
    coffee = entry.get('coffee_name', 'this coffee')
    verdict = entry.get('your_verdict', '')
    
    caption = f"""☕ {coffee}

{verdict[:150]}...

Brewed on {entry.get('brew_method', 'V60')} with {entry.get('grinder', 'precision grinder')} at {entry.get('ratio', '1:15')}.

The {entry.get('process', 'process')} really shines through — {entry.get('technical_enrichment', 'clean and structured')[:80]}.

Sentiment: {entry.get('sentiment_score', 8.5)}/10

#SpecialtyCoffee #CoffeeArchive #PourOver #Geisha #CoffeeJournal #ThirdWaveCoffee #SingaporeCoffee #BaliCoffee #KenyaAA #EthiopiaCoffee #PanamaGeisha #CoffeeTasting #FilterCoffee #CoffeeLover #HariCoffee2026"""

    return caption[:2000]  # Instagram limit