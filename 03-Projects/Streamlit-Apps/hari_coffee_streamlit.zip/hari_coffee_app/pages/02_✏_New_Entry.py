import streamlit as st
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from components.entry_form import render_entry_form
from database.queries import get_entry_by_id, get_all_entries

st.set_page_config(page_title="New Entry - Hari's Coffee Archive", layout="wide")

st.title("✏️ New Audit Entry")

# Mode selector
mode = st.radio(
    "Mode",
    ["🆕 New Entry", "✏️ Edit Existing"],
    horizontal=True,
    key="entry_mode"
)

if mode == "✏️ Edit Existing":
    df = get_all_entries()
    if df.empty:
        st.warning("No entries available to edit. Create a new entry first.")
        st.stop()
    
    # Create selection options
    options = []
    for _, row in df.iterrows():
        label = f"#{row.get('id', '?')} — {row.get('coffee_name', 'Unknown')} @ {row.get('cafe_name', 'Unknown')} ({row.get('date', '')})"
        options.append((label, row.get('id')))
    
    selected = st.selectbox("Select entry to edit", [o[0] for o in options])
    entry_id = next((o[1] for o in options if o[0] == selected), None)
    
    if entry_id:
        existing = get_entry_by_id(entry_id)
        result = render_entry_form(existing_entry=existing)
        if result:
            st.success("Entry updated successfully!")
else:
    # New entry
    result = render_entry_form()
    if result:
        st.success("New entry created!")