// nav.js - Shared navigation for Hari Coffee Archive tools
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.createElement('nav');
  nav.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#0d0d0d;border-bottom:1px solid #c9a84c;padding:8px 16px;z-index:1000;display:flex;align-items:center;justify-content:space-between;';
  nav.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;">
      <span style="color:#c9a84c;font-family:'Playfair Display',serif;font-size:18px;font-weight:700;">☕ Hari Coffee Archive 2026</span>
      <span style="color:#888;font-size:12px;">v3 • 31 entries</span>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <a href="sensory_vocabulary.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Vocabulary</a>
      <a href="varietal_tree.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Varietals</a>
      <a href="harvest_calendar.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Harvest</a>
      <a href="recipe_cards.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Recipes</a>
      <a href="timeline_visualiser.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Timeline</a>
      <a href="cafe_comparison.html" style="color:#c9a84c;text-decoration:none;font-size:13px;padding:6px 12px;border:1px solid #c9a84c;border-radius:4px;">Cafes</a>
    </div>
  `;
  document.body.prepend(nav);
  // Adjust body padding for fixed nav
  document.body.style.paddingTop = '60px';
});
