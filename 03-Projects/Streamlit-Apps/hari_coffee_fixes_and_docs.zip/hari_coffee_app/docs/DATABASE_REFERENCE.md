# Database Reference — Hari's Coffee Archive 2026

**Version:** 1.0.1  
**Total Tables:** 7  
**Seed Data:** 31 archive entries + 20 goals + 5 wishlist items

---

## 1. TABLE: coffee_archive

**Purpose:** Core audit log of every coffee tasted.

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | Primary Key |
| entry_num | INTEGER | Yes | NULL | Sequential number |
| date | TEXT | No | — | YYYY-MM-DD |
| city | TEXT | Yes | NULL | e.g. "Singapore", "Ubud, Bali" |
| cafe_name | TEXT | No | — | e.g. "Nylon Coffee Roasters" |
| coffee_name | TEXT | No | — | e.g. "Panama Corpachi Geisha" |
| varietal | TEXT | Yes | NULL | e.g. "Geisha", "Sudan Rume" |
| process | TEXT | Yes | NULL | e.g. "Washed", "Natural", "Anaerobic" |
| roast_level | TEXT | Yes | NULL | "Light", "Filter Roast", etc. |
| brew_method | TEXT | Yes | NULL | "V60 Pour-over", "Flat-Bottom (Hario Alpha)" |
| dose_g | REAL | Yes | NULL | e.g. 15.0 |
| yield_g | REAL | Yes | NULL | e.g. 225.0 |
| ratio | TEXT | Yes | NULL | "1:15" |
| bloom | TEXT | Yes | NULL | "30g / 30s" |
| grinder | TEXT | Yes | NULL | "Mahlkönig CORE (54mm flat)" |
| price_local | TEXT | Yes | NULL | "SGD 12.50" |
| official_notes | TEXT | Yes | NULL | Comma-separated tags |
| your_verdict | TEXT | No | — | Free-text tasting notes |
| technical_enrichment | TEXT | Yes | NULL | Hardware + chemistry explanation |
| rating | INTEGER | Yes | 0 | 1–5 stars |
| is_partial | INTEGER | Yes | 0 | 1 = limited data |
| is_draft | INTEGER | Yes | 0 | 1 = draft only |
| sentiment_score | REAL | Yes | 0 | 0.0–10.0 (auto-calculated) |
| created_at | TEXT | Yes | NULL | ISO timestamp |
| updated_at | TEXT | Yes | NULL | ISO timestamp |

**Indexes:** None (small dataset — full table scans acceptable)

**Sample Row (Entry #15):**
```json
{
  "id": 15,
  "date": "2026-04-05",
  "city": "Singapore",
  "cafe_name": "Asylum Coffeehouse",
  "coffee_name": "Castillo Watermelon (Jairo Arcila)",
  "varietal": "Castillo",
  "process": "Washed Co-Ferment",
  "roast_level": "Unknown",
  "brew_method": "Pour-over",
  "dose_g": 15.0,
  "yield_g": 225.0,
  "ratio": "1:15",
  "grinder": "Timemore Sculptor 078 (SSP)",
  "price_local": "12.50",
  "official_notes": "Watermelon; Mint; Lime; Chocolate",
  "your_verdict": "Distinct fruit-forward expression; sweetness layered rather than sharp",
  "technical_enrichment": "Fermentation adds aromatic complexity; processing-driven identity rather than terroir.",
  "rating": 4,
  "sentiment_score": 8.2
}
```

---

## 2. TABLE: beans

**Purpose:** Track physical bags of coffee (inventory + degassing).

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| roaster | TEXT | Yes | NULL | e.g. "Nylon Coffee Roasters" |
| coffee_name | TEXT | Yes | NULL | Full name |
| varietal | TEXT | Yes | NULL | |
| process | TEXT | Yes | NULL | |
| roast_date | TEXT | Yes | NULL | ISO date |
| purchase_date | TEXT | Yes | NULL | ISO date |
| weight_g | INTEGER | Yes | NULL | Original weight |
| weight_remaining_g | INTEGER | Yes | NULL | Current weight |
| price_sgd | REAL | Yes | NULL | Total paid |
| where_bought | TEXT | Yes | NULL | |
| is_finished | INTEGER | Yes | 0 | 1 = empty |
| finished_date | TEXT | Yes | NULL | |
| final_rating | INTEGER | Yes | NULL | 1–5 |
| created_at | TEXT | Yes | NULL | |

---

## 3. TABLE: brew_sessions

**Purpose:** Log every brew from a specific bean bag.

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| bean_id | INTEGER | Yes | NULL | FK → beans.id |
| session_date | TEXT | Yes | NULL | |
| brew_method | TEXT | Yes | NULL | |
| dose_g | REAL | Yes | NULL | |
| yield_g | REAL | Yes | NULL | |
| ratio | TEXT | Yes | NULL | |
| grinder | TEXT | Yes | NULL | |
| temp_c | INTEGER | Yes | NULL | |
| tasting_note | TEXT | Yes | NULL | |
| rating | INTEGER | Yes | NULL | 1–5 |
| hot_note | TEXT | Yes | NULL | |
| mid_note | TEXT | Yes | NULL | |
| cool_note | TEXT | Yes | NULL | |

**Relationships:**
- `brew_sessions.bean_id` → `beans.id` (one bean → many sessions)

---

## 4. TABLE: wishlist

**Purpose:** Future coffees to try (match scoring).

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| coffee_name | TEXT | Yes | NULL | |
| origin | TEXT | Yes | NULL | |
| process | TEXT | Yes | NULL | |
| varietal | TEXT | Yes | NULL | |
| match_percent | INTEGER | Yes | NULL | 50–100 |
| why_fits | TEXT | Yes | NULL | Explanation |
| estimated_price | TEXT | Yes | NULL | |
| where_to_find | TEXT | Yes | NULL | |
| is_purchased | INTEGER | Yes | 0 | 1 = bought |
| purchased_date | TEXT | Yes | NULL | |

---

## 5. TABLE: goals

**Purpose:** H2 2026 personal coffee goals.

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| title | TEXT | Yes | NULL | Short title |
| description | TEXT | Yes | NULL | Full description |
| category | TEXT | Yes | NULL | Enum: Audit \| Origin \| Hardware \| Knowledge \| Website |
| priority | TEXT | Yes | NULL | High \| Medium \| Low |
| is_complete | INTEGER | Yes | 0 | 0/1 |
| complete_date | TEXT | Yes | NULL | |
| notes | TEXT | Yes | NULL | |
| target_date | TEXT | Yes | NULL | YYYY-MM-DD |

**Category Values (enum):**
- Audit
- Origin
- Hardware
- Knowledge
- Website

---

## 6. TABLE: journal_entries

**Purpose:** Free-form reflective writing.

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| title | TEXT | Yes | NULL | Optional |
| body | TEXT | Yes | NULL | Main text |
| tags | TEXT | Yes | NULL | Comma-separated (#tasting, #science...) |
| mood | TEXT | Yes | NULL | ☕ Normal \| 🤔 Reflective \| 💡 Discovery \| ⭐ Milestone \| ❓ Question |
| linked_entry_id | INTEGER | Yes | NULL | Optional FK → coffee_archive.id |
| word_count | INTEGER | Yes | NULL | Auto-calculated |
| created_at | TEXT | Yes | NULL | |
| updated_at | TEXT | Yes | NULL | |

**Tags Format:** Comma-separated strings, e.g. "#tasting,#science,#gear"

---

## 7. TABLE: saved_recipes

**Purpose:** Reusable brew recipes.

| Column | Type | Nullable | Default | Notes |
|--------|------|----------|---------|-------|
| id | INTEGER | No | AUTOINCREMENT | PK |
| recipe_name | TEXT | Yes | NULL | |
| origin | TEXT | Yes | NULL | |
| varietal | TEXT | Yes | NULL | |
| process | TEXT | Yes | NULL | |
| brew_method | TEXT | Yes | NULL | |
| dose_g | REAL | Yes | NULL | |
| yield_g | REAL | Yes | NULL | |
| ratio | TEXT | Yes | NULL | |
| temp_c | INTEGER | Yes | NULL | |
| bloom_g | REAL | Yes | NULL | |
| bloom_time_s | INTEGER | Yes | NULL | |
| pour_notes | TEXT | Yes | NULL | |
| created_at | TEXT | Yes | NULL | |

---

## 8. QUERY REFERENCE (Selected Key Functions)

### get_all_entries(filters=None) → pd.DataFrame
Returns all archive entries (merged CSV + session_state in cloud). Optional filters dict supported.

### calculate_sentiment(verdict: str) → float
Scores 0–10 based on keyword presence. See full algorithm in Section 9.

### insert_entry(data: dict) → int
Inserts new row. Returns new ID. Handles both local SQLite and cloud session_state.

### get_top_entries(n=5) → pd.DataFrame
Returns n entries with highest sentiment_score.

### get_process_counts() → pd.DataFrame
Returns value counts of process types for donut chart.

### insert_bean(data: dict) → int
Creates new bean bag record.

### complete_goal(goal_id: int) → bool
Marks goal as complete and sets complete_date.

### get_all_entries_merged() → pd.DataFrame
**Cloud-only helper.** Combines committed CSV with in-memory session_state entries.

---

## 9. SENTIMENT SCORING ALGORITHM

**Function:** `calculate_sentiment(verdict: str) → float`

**Algorithm:**
1. Start at base score = 5.0
2. Lowercase and split verdict into words
3. For each word:
   - If it contains any positive keyword → +0.5
   - If it contains any negative keyword → -0.3
4. Clamp result between 0.0 and 10.0
5. Round to 1 decimal place

**Positive Keywords (weight +0.5 each occurrence):**
`love, favourite, favorite, excellent, incredible, nice, great, good, clean, clear, precise, structured, elegant, textbook, terrific, outstanding, perfect`

**Negative Keywords (weight -0.3 each occurrence):**
`muddy, bitter, over, muted, heavy, short, flat, simple, weak, harsh`

**Example Scores from Real Archive:**
- "Damn the taste so nice — the orange nectarine finishing with that honey is terrific." → **9.0/10**
- "Love this one. So far my favourite." → **9.5/10**
- "Pretty good. Kiwi and oolong tea style, full bodied. Short finish." → **6.2/10**
- "Heavy body with rich cocoa notes." → **6.5/10**
- "Muddy, over-extracted, short finish." → **3.1/10**

**Calibration Note:** Scores are intentionally generous on positive language to reward detailed, enthusiastic tasting notes while still penalizing negative descriptors.