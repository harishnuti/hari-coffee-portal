// Hari Coffee Archive 2026 - Global Navigation Enhancement
document.addEventListener('DOMContentLoaded', () => {
    // Add subtle keyboard navigation hint
    const nav = document.querySelector('.nav');
    if (nav) {
        nav.setAttribute('aria-label', 'Main navigation');
    }
    
    // ESC key closes any open modals/panels (works across tools)
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const openPanel = document.querySelector('.deep-dive.open');
            if (openPanel) openPanel.classList.remove('open');
        }
    });
    
    console.log('%c[Hari Coffee] nav.js loaded — global enhancements active', 'color:#666');
});