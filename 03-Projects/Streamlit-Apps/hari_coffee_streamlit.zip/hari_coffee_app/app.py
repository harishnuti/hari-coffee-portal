import streamlit as st
import pandas as pd
from datetime import datetime
import sys
import os

# Add parent to path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database.connection import is_cloud, get_connection
from database.schema import init_db
from database.seed import seed_from_csv
from database.queries import get_entries_count, get_all_entries

# Page config
st.set_page_config(
    page_title="Hari's Coffee Archive 2026",
    page_icon="☕",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS - Dark theme with gold accents + Playfair Display
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;500;600&display=swap');

:root {
    --gold: #c9a84c;
    --dark: #0d0d0d;
    --card: #1a1a1a;
}

.stApp {
    background-color: #0d0d0d;
    color: #f5f5f5;
}

h1, h2, h3 {
    font-family: 'Playfair Display', serif;
    color: #c9a84c;
}

.stButton > button {
    background-color: #c9a84c;
    color: #0d0d0d;
    font-weight: 600;
    border: none;
    border-radius: 6px;
    padding: 0.5rem 1.5rem;
}

.stButton > button:hover {
    background-color: #d4b85c;
    color: #0d0d0d;
}

.stMetric {
    background-color: #1a1a1a;
    border-radius: 8px;
    padding: 1rem;
    border: 1px solid #333;
}

.stExpander {
    background-color: #1a1a1a;
    border-radius: 8px;
}

.sidebar .sidebar-content {
    background-color: #1a1a1a;
}

.gold-text {
    color: #c9a84c;
    font-weight: 600;
}
</style>
""", unsafe_allow_html=True)

# Initialize all session_state keys
def init_session_state():
    defaults = {
        'seeded': False,
        'new_entries': [],
        'beans': [],
        'brew_sessions': [],
        'wishlist': [],
        'goals': [],
        'journal_entries': [],
        'saved_recipes': [],
        'edit_entry_id': None,
        'selected_entry': None,
        'brew_bean_id': None,
        'brew_bean_name': None,
        'edit_journal_id': None,
        'export_entry': None,
        'active_filters': {}
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

init_session_state()

# Initialize database
init_db()

# Seed on first load (local mode)
csv_path = os.path.join(os.path.dirname(__file__), "data", "hari_coffee_master.csv")
if not st.session_state.get('seeded', False):
    seed_from_csv(csv_path)
    st.session_state['seeded'] = True

# Sidebar
with st.sidebar:
    st.markdown("## ☕ Hari Coffee Archive 2026")
    st.caption("Personal Specialty Coffee Audit System")
    
    # Stats
    total = get_entries_count()
    st.metric("Total Entries", total)
    
    last_date = "2026-05-19"
    try:
        df = get_all_entries()
        if not df.empty and 'date' in df.columns:
            last_date = df['date'].max()
    except:
        pass
    st.caption(f"Last visit: {last_date}")
    
    st.divider()
    
    st.markdown("### 📍 Navigation")
    st.caption("Use the sidebar menu or top navigation to explore:")
    st.caption("• Dashboard — Overview & analytics")
    st.caption("• New Entry — Smart audit form")
    st.caption("• Archive — Full searchable library")
    st.caption("• Brew Lab — Recipe calculator")
    st.caption("• Origins — Deep origin explorer")
    st.caption("• Bean Tracker — Bag management")
    st.caption("• Goals — H2 2026 tracking")
    st.caption("• Journal — Reflective writing")
    st.caption("• Export Hub — CSV, Gemini, Social")
    st.caption("• Settings — Data management")
    
    st.divider()
    
    mode = "☁️ Cloud (CSV + Session)" if is_cloud() else "💾 Local (SQLite)"
    st.caption(f"**Mode:** {mode}")
    if is_cloud():
        st.info("New entries saved to session only. Download CSV from Export Hub to persist.")

# Main page content
st.title("☕ Hari's Coffee Archive 2026")
st.markdown("### *Precision. Clarity. Memory.*")

# Hero KPI row
col1, col2, col3, col4 = st.columns(4)

df = get_all_entries()

with col1:
    st.metric("Total Audits", len(df) if not df.empty else 31, delta="+9 this month")

with col2:
    unique_cafes = df['cafe_name'].nunique() if not df.empty else 16
    st.metric("Cafes Visited", unique_cafes)

with col3:
    cities = df['city'].nunique() if not df.empty else 4
    st.metric("Cities Explored", cities)

with col4:
    varietals = df['varietal'].nunique() if not df.empty else 17
    st.metric("Varietals Documented", varietals)

st.divider()

# Quick actions
st.subheader("🚀 Quick Actions")

col1, col2, col3 = st.columns(3)

with col1:
    if st.button("✏️ New Audit Entry", use_container_width=True):
        st.switch_page("pages/02_✏️_New_Entry.py")

with col2:
    if st.button("📚 Browse Archive", use_container_width=True):
        st.switch_page("pages/03_📚_Archive.py")

with col3:
    if st.button("☕ Open Brew Lab", use_container_width=True):
        st.switch_page("pages/04_☕_Brew_Lab.py")

st.divider()

# Recent activity
st.subheader("🕐 Recent Activity")

if not df.empty:
    recent = df.head(6)
    from components.entry_card import render_entry_grid
    render_entry_grid(recent)
else:
    st.info("Welcome! Seed data loaded. Start by adding your first new entry or exploring the Dashboard.")

# Footer
st.divider()
st.caption("Built with precision for the specialty coffee community • 2026 • All rights reserved to Hari")