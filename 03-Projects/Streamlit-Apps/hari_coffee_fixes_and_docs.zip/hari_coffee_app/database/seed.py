import pandas as pd
from datetime import datetime
import streamlit as st
from .connection import get_connection, is_cloud
from .queries import insert_entry, insert_wishlist_item, insert_goal, get_entries_count

def calculate_sentiment(verdict: str) -> float:
    """Score 0-10 from verdict text"""
    if not verdict or pd.isna(verdict):
        return 5.0
    positive = ['love', 'favourite', 'excellent', 'incredible', 'nice', 'great', 
                'good', 'clean', 'clear', 'precise', 'structured', 'elegant', 
                'textbook', 'terrific', 'favourite', 'best', 'perfect']
    negative = ['muddy', 'bitter', 'over', 'muted', 'heavy', 'short', 'flat', 
                'simple', 'bad', 'poor']
    words = str(verdict).lower().split()
    score = 5.0
    for w in words:
        if any(p in w for p in positive):
            score += 0.6
        if any(n in w for n in negative):
            score -= 0.4
    return min(10.0, max(0.0, round(score, 1)))

def seed_from_csv(csv_path: str):
    """Seed database from CSV on first load"""
    if is_cloud():
        # In cloud mode, we don't seed SQLite, but ensure session_state is ready
        if 'seeded' not in st.session_state:
            st.session_state['seeded'] = True
            st.session_state['new_entries'] = []
            st.session_state['beans'] = []
            st.session_state['brew_sessions'] = []
            st.session_state['wishlist'] = []
            st.session_state['goals'] = []
            st.session_state['journal_entries'] = []
            st.session_state['saved_recipes'] = []
        return
    
    conn = get_connection()
    if conn is None:
        return
    
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM coffee_archive")
    count = cursor.fetchone()[0]
    
    if count > 0:
        conn.close()
        return  # Already seeded
    
    try:
        df = pd.read_csv(csv_path)
        df.columns = [c.strip().replace(' ', '_') for c in df.columns]
        
        for idx, row in df.iterrows():
            entry = {
                'entry_num': idx + 1,
                'date': row.get('Date', ''),
                'city': row.get('City', ''),
                'cafe_name': row.get('Cafe_Name', ''),
                'coffee_name': row.get('Coffee_Name', ''),
                'varietal': row.get('Varietal', ''),
                'process': row.get('Process', ''),
                'roast_level': row.get('Roast_Level', ''),
                'brew_method': row.get('Brew_Method', ''),
                'dose_g': row.get('Dose_g', None),
                'yield_g': row.get('Yield_g', None),
                'ratio': row.get('Ratio', ''),
                'bloom': row.get('Bloom', ''),
                'grinder': row.get('Grinder', ''),
                'price_local': row.get('Price_Local', ''),
                'official_notes': row.get('Official_Notes', ''),
                'your_verdict': row.get('Your_Verdict', ''),
                'technical_enrichment': row.get('Technical_Enrichment', ''),
                'rating': 4,  # Default rating
                'is_partial': 1 if 'Partial' in str(row.get('Technical_Enrichment', '')) else 0,
                'is_draft': 0,
                'sentiment_score': calculate_sentiment(row.get('Your_Verdict', '')),
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            }
            insert_entry(entry)
        
        # Pre-load wishlist
        wishlist_items = [
            {"coffee_name": "Colombia Gesha RSF4 Cold Washed", "origin": "Colombia", "process": "Washed", 
             "varietal": "Gesha", "match_percent": 98, "why_fits": "Washed Geisha with exceptional clarity and floral complexity matching your preference for high-transparency cups.", 
             "estimated_price": "SGD 28-35", "where_to_find": "Nylon Coffee Roasters or direct from roaster"},
            {"coffee_name": "Sudan Rume Finca El Paraiso", "origin": "Colombia", "process": "Washed", 
             "varietal": "Sudan Rume", "match_percent": 95, "why_fits": "Rare genetics with bright acidity and tea-like body - aligns with your Wush Wush and Gesha explorations.", 
             "estimated_price": "SGD 32-40", "where_to_find": "Specialty importers via Kurasu or direct"},
            {"coffee_name": "Peru Black Honey Geisha", "origin": "Peru", "process": "Black Honey", 
             "varietal": "Gesha", "match_percent": 92, "why_fits": "Honey process adds roundness to Geisha florals without fermentation noise - perfect evolution from your Peru Gesha entry.", 
             "estimated_price": "SGD 25-32", "where_to_find": "Asylum Coffeehouse or Grey Soul"},
            {"coffee_name": "Panama Tierra Blanca Geisha Washed", "origin": "Panama", "process": "Washed", 
             "varietal": "Gesha", "match_percent": 85, "why_fits": "Classic Panama Geisha terroir with bright citrus and jasmine - benchmark for comparison with Ecuador and Peru entries.", 
             "estimated_price": "SGD 30-38", "where_to_find": "Lume Cafe or direct import"},
            {"coffee_name": "Inmaculada Laurina Washed", "origin": "Colombia", "process": "Washed", 
             "varietal": "Hybrid Laurina", "match_percent": 88, "why_fits": "Low-caffeine Laurina with clean honeyed finish and hibiscus notes - matches your Ijen Laurina preference.", 
             "estimated_price": "SGD 22-28", "where_to_find": "FLUID or Alchemist"}
        ]
        for item in wishlist_items:
            insert_wishlist_item(item)
        
        # Pre-load 20 goals
        goals_list = [
            # Audit category
            {"title": "Reach 50 entries", "description": "Complete 50 full archive entries by end of 2026", "category": "Audit", "priority": "High", "is_complete": 0, "target_date": "2026-12-31"},
            {"title": "Homeground Finca Deborah", "description": "Audit Finca Deborah Gesha from home setup with full technical notes", "category": "Audit", "priority": "Medium", "is_complete": 0, "target_date": "2026-08-15"},
            {"title": "Exposure Therapy", "description": "Complete 3 blind origin identification sessions with 80%+ accuracy", "category": "Audit", "priority": "High", "is_complete": 0, "target_date": "2026-07-01"},
            {"title": "Aera Experiments", "description": "Run 5 Aera flash-chill audits with temperature logging", "category": "Audit", "priority": "Medium", "is_complete": 0, "target_date": "2026-09-30"},
            {"title": "Colombia La Laja at Nylon", "description": "Re-audit Colombia La Laja (Sudan Rume) at Nylon after 30+ days rest", "category": "Audit", "priority": "Low", "is_complete": 0, "target_date": "2026-06-15"},
            # Origin category
            {"title": "Ethiopia+Kenya+Rwanda trifecta", "description": "Complete one full entry from each of Ethiopia, Kenya, and Rwanda in single month", "category": "Origin", "priority": "High", "is_complete": 0, "target_date": "2026-08-31"},
            {"title": "First Yemen natural", "description": "Source and audit first Yemen natural coffee", "category": "Origin", "priority": "High", "is_complete": 0, "target_date": "2026-10-31"},
            {"title": "First Bolivia", "description": "Audit first Bolivian coffee (preferably Geisha or Pacamara)", "category": "Origin", "priority": "Medium", "is_complete": 0, "target_date": "2026-11-30"},
            # Hardware category
            {"title": "Same bean EK43 vs P64 comparison", "description": "Side-by-side audit of identical bean on EK43 (98mm) vs Lagom P64 (64mm)", "category": "Hardware", "priority": "High", "is_complete": 0, "target_date": "2026-07-15"},
            {"title": "Flash-chill proper audit", "description": "Complete 3 flash-chill brews with full thermal logging and sensory mapping", "category": "Hardware", "priority": "Medium", "is_complete": 0, "target_date": "2026-08-01"},
            # Knowledge category
            {"title": "Predict 3 origins blind", "description": "Correctly identify origin of 3 unknown samples in blind tasting", "category": "Knowledge", "priority": "High", "is_complete": 0, "target_date": "2026-06-30"},
            {"title": "5 consecutive correct acid IDs", "description": "Identify primary acid (citric/malic/tartaric/lactic) in 5 consecutive cups", "category": "Knowledge", "priority": "Medium", "is_complete": 0, "target_date": "2026-07-31"},
            # Website category
            {"title": "Deploy Netlify portfolio", "description": "Deploy personal coffee archive site on Netlify with 31 Gemini infographics", "category": "Website", "priority": "High", "is_complete": 0, "target_date": "2026-09-15"},
            {"title": "31 Gemini infographics", "description": "Generate and publish 31 custom Gemini infographic prompts for all archive entries", "category": "Website", "priority": "High", "is_complete": 0, "target_date": "2026-08-31"},
            {"title": "100 unique visitors", "description": "Reach 100 unique visitors on coffee archive site", "category": "Website", "priority": "Medium", "is_complete": 0, "target_date": "2026-12-31"},
            # Additional goals
            {"title": "Complete Indonesia deep dive", "description": "Audit 5 Indonesian origins (including 2 wet-hulled) with full technical notes", "category": "Origin", "priority": "Medium", "is_complete": 0, "target_date": "2026-09-30"},
            {"title": "Master flat-bottom geometry", "description": "Document 10 flat-bottom brews with Hario Alpha / xBloom with thermal profiling", "category": "Hardware", "priority": "High", "is_complete": 0, "target_date": "2026-08-15"},
            {"title": "Build bean tracker v2", "description": "Implement weight tracking + cost-per-brew analytics in Bean Tracker", "category": "Website", "priority": "Low", "is_complete": 0, "target_date": "2026-10-31"},
            {"title": "Host first coffee tasting event", "description": "Organize and host 1 coffee tasting event with 4-6 participants", "category": "Knowledge", "priority": "Medium", "is_complete": 0, "target_date": "2026-11-15"},
            {"title": "Publish 2026 year-in-review", "description": "Create and publish comprehensive 2026 coffee archive year-in-review report", "category": "Website", "priority": "High", "is_complete": 0, "target_date": "2026-12-20"}
        ]
        for goal in goals_list:
            insert_goal(goal)
        
        st.session_state['seeded'] = True
        conn.close()
        
    except Exception as e:
        st.error(f"Seeding failed: {e}")
        if conn:
            conn.close()

# Alias for compatibility with Settings page and other callers
seed_database = seed_from_csv