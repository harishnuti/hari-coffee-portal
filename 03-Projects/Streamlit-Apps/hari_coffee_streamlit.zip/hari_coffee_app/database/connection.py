import os
import sqlite3
import pandas as pd
from pathlib import Path

def is_cloud() -> bool:
    """Detect Streamlit Cloud environment"""
    return bool(
        os.environ.get('STREAMLIT_SHARING_MODE') or
        os.environ.get('STREAMLIT_SERVER_HEADLESS') or
        os.path.exists('/home/appuser') or
        os.environ.get('STREAMLIT_CLOUD') == 'true'
    )

def get_db_path() -> str:
    """Return path to SQLite DB file"""
    base_dir = Path(__file__).parent.parent
    return str(base_dir / "coffee_archive.db")

def get_connection():
    """Returns sqlite3 connection (local) or None (cloud)"""
    if is_cloud():
        return None
    db_path = get_db_path()
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn