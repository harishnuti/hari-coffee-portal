# Hari's Coffee Archive — System Architecture

**Version:** 1.0.1  
**Date:** 20 May 2026  
**Author:** Hari (built with precision)

---

## 1. SYSTEM OVERVIEW

```
┌─────────────────────────────────────────────────────────────────┐
│                    HARI COFFEE ARCHIVE 2026                     │
│                  Full System Architecture                       │
└─────────────────────────────────────────────────────────────────┘

                          ┌──────────────────────┐
                          │   Streamlit App      │
                          │   (10 Pages)         │
                          │   app.py + pages/    │
                          └──────────┬───────────┘
                                     │
          ┌──────────────────────────┼──────────────────────────┐
          │                          │                          │
   ┌──────▼──────┐            ┌──────▼──────┐            ┌──────▼──────┐
   │  Database   │            │ Components  │            │  Export     │
   │  Layer      │            │ Library     │            │  Pipeline   │
   │             │            │             │            │             │
   │ • connection│            │ • charts    │            │ • exporters │
   │ • schema    │            │ • entry_form│            │ • Gemini    │
   │ • queries   │            │ • entry_card│            │ • Instagram │
   │ • seed      │            │ • exporters │            │ • Twitter   │
   └──────┬──────┘            └──────┬──────┘            └──────┬──────┘
          │                          │                          │
   ┌──────▼──────┐            ┌──────▼──────┐            ┌──────▼──────┐
   │ Local Mode  │            │ Netlify     │            │ GitHub      │
   │ SQLite      │            │ Static Site │            │ Repository  │
   │ coffee_     │            │ (future)    │            │ (source of  │
   │ archive.db  │            │             │            │ truth)      │
   └─────────────┘            └─────────────┘            └─────────────┘

   Cloud Mode: CSV (committed) + st.session_state (runtime)
   Gemini AI Pipeline: exporters.py → prompt → Gemini → infographic
   Supabase (future): Optional backend for multi-user sync
```

**Core Philosophy:** Precision, clarity, and memory. Every cup is documented with technical depth and emotional resonance.

---

## 2. DUAL-MODE DATABASE ARCHITECTURE

### Local Mode (Development / Personal Use)
```
Streamlit App
     │
     ▼
database/connection.py
     │
     ├─► is_cloud() → False
     │
     ▼
get_connection() → sqlite3.Connection
     │
     ▼
coffee_archive.db (persistent on disk)
     │
     ▼
Full CRUD (INSERT/UPDATE/DELETE)
```

### Cloud Mode (Streamlit Sharing)
```
Streamlit App
     │
     ▼
database/connection.py
     │
     ├─► is_cloud() → True (detects STREAMLIT_SERVER_HEADLESS or /home/appuser)
     │
     ▼
No SQLite connection returned
     │
     ▼
CSV (data/hari_coffee_master.csv) + st.session_state['new_entries']
     │
     ▼
get_all_entries_merged() combines both
     │
     ▼
Export Hub → Download updated CSV → User commits to GitHub
```

**Detection Logic (connection.py):**
```python
IS_CLOUD = bool(
    os.environ.get('STREAMLIT_SHARING_MODE') or
    os.environ.get('STREAMLIT_SERVER_HEADLESS') or
    os.path.exists('/home/appuser')
)
```

**Persistence Strategy:**
- Local: Immediate disk write via SQLite
- Cloud: Session-only until user manually exports CSV and commits

---

## 3. FILE DEPENDENCY MAP

```
app.py
├── from database.connection import is_cloud, get_connection
├── from database.schema import init_db
├── from database.seed import seed_from_csv
├── from database.queries import get_entries_count, get_all_entries
└── from components.entry_card import render_entry_grid

pages/01_📊_Dashboard.py
├── from database.queries import get_all_entries, get_entries_count...
├── from components.charts import render_process_donut, render_top_entries_bar...

pages/02_✏️_New_Entry.py
└── from components.entry_form import render_entry_form

pages/03_📚_Archive.py
├── from database.queries import get_all_entries, delete_entry...
└── from components.entry_card import render_entry_grid, render_entry_table

components/entry_form.py
├── from database.queries import get_unique_cafes, get_cafe_city_map...
└── from database.seed import calculate_sentiment   ← (now also in queries.py)

components/charts.py
└── import plotly.graph_objects as go

database/queries.py
├── from .connection import get_connection, is_cloud
└── import streamlit as st (for session_state in cloud mode)

database/seed.py
└── from .queries import insert_entry, insert_wishlist_item...
```

---

## 4. DATA FLOW DIAGRAM (New Audit Entry)

```
User opens New Entry page
          │
          ▼
components/entry_form.py renders 7-section smart form
          │
          ▼
User fills fields (auto city/grinder fill, live ratio calc)
          │
          ▼
User clicks "Submit Entry"
          │
          ▼
Validation (required: date, cafe_name, coffee_name, verdict)
          │
          ▼
calculate_sentiment(your_verdict) → score 0-10
          │
          ▼
insert_entry(data) in database/queries.py
          │
     ┌────┴────┐
     │         │
Local:    Cloud:
SQLite    session_state['new_entries'].append(data)
INSERT
          │
          ▼
Entry appears immediately in Archive / Dashboard
          │
          ▼
exporters.py generates:
  • CSV line (exact 17-column format)
  • Gemini infographic prompt (5-section)
  • Instagram caption + 15 hashtags
          │
          ▼
User copies CSV line → pastes into master CSV (or downloads full export)
```

---

## 5. DATABASE SCHEMA DIAGRAM

```
┌─────────────────────┐
│   coffee_archive    │
├─────────────────────┤
│ id (PK, AUTOINC)    │
│ entry_num           │
│ date                │
│ city                │
│ cafe_name           │
│ coffee_name         │
│ varietal            │
│ process             │
│ roast_level         │
│ brew_method         │
│ dose_g (REAL)       │
│ yield_g (REAL)      │
│ ratio               │
│ bloom               │
│ grinder             │
│ price_local         │
│ official_notes      │
│ your_verdict        │
│ technical_enrichment│
│ rating (INT)        │
│ is_partial (INT)    │
│ is_draft (INT)      │
│ sentiment_score     │
│ created_at          │
│ updated_at          │
└─────────────────────┘
          │
          │ (future: linked_entry_id)
          ▼
┌─────────────────────┐       ┌─────────────────────┐
│  journal_entries    │       │       beans         │
├─────────────────────┤       ├─────────────────────┤
│ id (PK)             │       │ id (PK)             │
│ title               │       │ roaster             │
│ body                │       │ coffee_name         │
│ tags                │       │ varietal            │
│ mood                │       │ process             │
│ linked_entry_id     │◄──────│ roast_date          │
│ word_count          │       │ weight_g            │
│ created_at          │       │ weight_remaining_g  │
└─────────────────────┘       │ price_sgd           │
                              │ is_finished         │
                              └─────────┬───────────┘
                                        │
                                        ▼
                              ┌─────────────────────┐
                              │   brew_sessions     │
                              ├─────────────────────┤
                              │ id (PK)             │
                              │ bean_id (FK → beans)│
                              │ session_date        │
                              │ brew_method         │
                              │ dose_g, yield_g     │
                              │ rating              │
                              │ hot_note, mid_note, │
                              │ cool_note           │
                              └─────────────────────┘

Other standalone tables:
- wishlist (coffee_name, match_percent, why_fits...)
- goals (title, category, priority, is_complete...)
- saved_recipes (recipe_name, origin, dose_g, temp_c...)
```

---

## 6. COMPONENT LIBRARY REFERENCE

| File | Exported Functions | Used By | Contract |
|------|--------------------|---------|----------|
| `components/charts.py` | render_process_donut(df), render_origin_bar(df), render_palate_radar(scores), render_world_map(df), render_degassing_gauge(date), render_top_entries_bar(df), ... (9 total) | Dashboard, Origins, Brew Lab | Input: pd.DataFrame or dict → Output: plotly.graph_objects.Figure |
| `components/entry_form.py` | render_entry_form(existing_entry=None) | New Entry page | Returns dict on submit or None |
| `components/entry_card.py` | render_entry_card(entry, expanded=False), render_entry_grid(df), render_entry_table(df) | Archive, Dashboard | Renders styled cards with process color badges |
| `components/exporters.py` | generate_csv_line, generate_gemini_prompt, generate_instagram_caption, generate_twitter_thread, generate_maps_review, generate_share_card | Export Hub, New Entry success | All take entry dict → return formatted string |

---

## 7. PAGE INVENTORY TABLE

| Page | File | Purpose | Key Functions Used |
|------|------|---------|--------------------|
| Dashboard | 01_📊_Dashboard.py | Overview + KPIs + charts | get_all_entries, 9 chart renderers |
| New Entry | 02_✏️_New_Entry.py | Smart audit form (edit + create) | render_entry_form |
| Archive | 03_📚_Archive.py | Searchable library (cards/table/compact) | get_all_entries + filters, render_entry_grid |
| Brew Lab | 04_☕_Brew_Lab.py | Recipe calculator + saved recipes | calculate_recipe logic, insert_saved_recipe |
| Origins | 05_🌍_Origins.py | World map + terroir profiles | render_world_map, hardcoded ORIGIN_PROFILES |
| Bean Tracker | 06_🫘_Bean_Tracker.py | 5-tab bag management | get_all_beans, insert_bean, degassing gauge |
| Goals | 07_🎯_Goals.py | H2 2026 goal tracking | get_all_goals, complete_goal |
| Journal | 08_📝_Journal.py | Reflective writing + mood | insert_journal_entry, get_all_journal_entries |
| Export Hub | 09_📤_Export_Hub.py | CSV/JSON/Gemini/Social exports | All 6 exporter functions |
| Settings | 10_⚙️_Settings.py | Stats, import, backup, danger zone | get_entries_count, seed_database, init_db |

---

## 8. DEPLOYMENT ARCHITECTURE

**PATH A — Local Development**
```
git clone https://github.com/hari/hari-coffee-archive.git
cd hari_coffee_app
pip install -r requirements.txt
streamlit run app.py
```
- Data stored in `coffee_archive.db` (auto-created + seeded)
- Full read/write/delete

**PATH B — Streamlit Cloud (Production)**
```
GitHub repo (main branch)
        │
        ▼
share.streamlit.io → New app → Select repo → app.py → Deploy
        │
        ▼
Live URL: https://username-hari-coffee-archive.streamlit.app
        │
        ▼
Data source: data/hari_coffee_master.csv (committed)
New entries: st.session_state (temporary)
Persistence: Export Hub → Download CSV → git commit & push
```

This architecture guarantees the app runs identically in both environments while providing a clear persistence path for cloud users.