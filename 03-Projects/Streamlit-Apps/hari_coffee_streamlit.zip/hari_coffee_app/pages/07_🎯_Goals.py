import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import get_all_goals, complete_goal, insert_goal

st.set_page_config(page_title="Goals - Hari's Coffee Archive", layout="wide")

st.title("🎯 H2 2026 Goals")

goals = get_all_goals()

if goals.empty:
    st.info("No goals loaded. Seeding should have populated them.")
else:
    completed = goals[goals['is_complete'] == 1]
    total = len(goals)
    pct = (len(completed) / total * 100) if total > 0 else 0
    
    st.progress(pct / 100)
    st.caption(f"**{len(completed)}/{total}** goals complete ({pct:.0f}%)")
    
    # Palate radar repurposed
    from components.charts import render_palate_radar
    scores = {'Audit': 65, 'Origin': 45, 'Hardware': 70, 'Knowledge': 55, 'Website': 30}
    st.plotly_chart(render_palate_radar(scores), use_container_width=True)
    
    categories = ['Audit', 'Origin', 'Hardware', 'Knowledge', 'Website']
    
    for cat in categories:
        cat_goals = goals[goals['category'] == cat]
        done = len(cat_goals[cat_goals['is_complete'] == 1])
        total_cat = len(cat_goals)
        
        with st.expander(f"{cat} Goals ({done}/{total_cat})", expanded=True):
            for _, goal in cat_goals.iterrows():
                col1, col2 = st.columns([5, 1])
                
                checked = bool(goal['is_complete'])
                if col1.checkbox(
                    goal['title'],
                    value=checked,
                    key=f"goal_{goal['id']}"
                ):
                    if not checked:
                        complete_goal(goal['id'])
                        st.rerun()
                
                col1.caption(goal['description'])
                
                priority = goal.get('priority', 'Medium')
                color = {'High': '#e05252', 'Medium': '#fb923c', 'Low': '#4ade80'}.get(priority, '#6b7280')
                col1.markdown(f"<span style='color:{color}'>**{priority}**</span>", unsafe_allow_html=True)
                
                if goal['is_complete']:
                    col2.success("✅")
                    if goal.get('complete_date'):
                        col2.caption(goal['complete_date'][:10])

# Add new goal
with st.expander("➕ Add New Goal"):
    with st.form("new_goal"):
        title = st.text_input("Title")
        desc = st.text_area("Description")
        cat = st.selectbox("Category", categories)
        pri = st.selectbox("Priority", ['High', 'Medium', 'Low'])
        target = st.date_input("Target Date")
        
        if st.form_submit_button("Create Goal"):
            insert_goal({
                'title': title,
                'description': desc,
                'category': cat,
                'priority': pri,
                'target_date': str(target),
                'is_complete': 0
            })
            st.success("Goal added!")
            st.rerun()