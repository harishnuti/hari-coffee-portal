import sqlite3
import pandas as pd
from datetime import datetime
from .connection import get_connection, is_cloud, get_db_path
import streamlit as st

def calculate_sentiment(verdict: str) -> float:
    """Score 0-10 from verdict keywords"""
    if not verdict or pd.isna(verdict):
        return 5.0
    positive = ['love','favourite','favorite','excellent',
                'incredible','nice','great','good','clean',
                'clear','precise','structured','elegant',
                'textbook','terrific','outstanding','perfect']
    negative = ['muddy','bitter','over','muted','heavy',
                'short','flat','simple','weak','harsh']
    words = str(verdict).lower().split()
    score = 5.0
    for w in words:
        if any(p in w for p in positive): score += 0.5
        if any(n in w for n in negative): score -= 0.3
    return round(min(10.0, max(0.0, score)), 1)

# Cloud mode helpers
def get_entries_from_state() -> pd.DataFrame:
    """Get entries from session_state in cloud mode"""
    if 'new_entries' not in st.session_state or not st.session_state['new_entries']:
        return pd.DataFrame()
    return pd.DataFrame(st.session_state['new_entries'])

def add_entry_to_state(data: dict):
    """Add new entry to session_state in cloud mode"""
    if 'new_entries' not in st.session_state:
        st.session_state['new_entries'] = []
    st.session_state['new_entries'].append(data)

def get_all_entries_merged() -> pd.DataFrame:
    """Merges CSV + session_state entries in cloud mode"""
    if not is_cloud():
        return get_all_entries()
    
    # In cloud: read from CSV + session_state
    try:
        csv_df = pd.read_csv('/home/workdir/artifacts/hari_coffee_app/data/hari_coffee_master.csv')
        # Standardize column names
        csv_df.columns = [c.strip().replace(' ', '_') for c in csv_df.columns]
        csv_df['source'] = 'csv'
    except:
        csv_df = pd.DataFrame()
    
    state_df = get_entries_from_state()
    if not state_df.empty:
        state_df['source'] = 'session'
    
    if csv_df.empty:
        return state_df
    if state_df.empty:
        return csv_df
    
    # Align columns
    all_cols = list(set(csv_df.columns) | set(state_df.columns))
    for col in all_cols:
        if col not in csv_df.columns:
            csv_df[col] = None
        if col not in state_df.columns:
            state_df[col] = None
    
    return pd.concat([csv_df, state_df], ignore_index=True)

# Archive CRUD
def get_all_entries(filters=None) -> pd.DataFrame:
    """Get all entries with optional filters"""
    if is_cloud():
        df = get_all_entries_merged()
    else:
        conn = get_connection()
        if conn is None:
            return pd.DataFrame()
        try:
            df = pd.read_sql_query("SELECT * FROM coffee_archive ORDER BY date DESC", conn)
            conn.close()
        except:
            return pd.DataFrame()
    
    if filters and not df.empty:
        if 'city' in filters and filters['city']:
            df = df[df['city'].isin(filters['city'])]
        if 'process' in filters and filters['process']:
            df = df[df['process'].isin(filters['process'])]
        if 'varietal' in filters and filters['varietal']:
            df = df[df['varietal'].isin(filters['varietal'])]
        if 'cafe' in filters and filters['cafe']:
            df = df[df['cafe_name'].isin(filters['cafe'])]
        if 'search' in filters and filters['search']:
            search = filters['search'].lower()
            mask = (df['coffee_name'].str.lower().str.contains(search, na=False) |
                    df['your_verdict'].str.lower().str.contains(search, na=False) |
                    df['cafe_name'].str.lower().str.contains(search, na=False))
            df = df[mask]
        if 'rating_min' in filters and filters['rating_min'] > 0:
            df = df[df['rating'] >= filters['rating_min']]
        if 'partial' in filters and not filters['partial']:
            df = df[df['is_partial'] == 0]
    
    return df

def get_entry_by_id(entry_id) -> dict:
    """Get single entry by ID"""
    if is_cloud():
        df = get_all_entries_merged()
        if 'id' in df.columns:
            match = df[df['id'] == entry_id]
        else:
            match = df.iloc[[entry_id]] if entry_id < len(df) else pd.DataFrame()
        if not match.empty:
            return match.iloc[0].to_dict()
        return {}
    else:
        conn = get_connection()
        if conn is None:
            return {}
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM coffee_archive WHERE id = ?", (entry_id,))
            row = cursor.fetchone()
            conn.close()
            if row:
                return dict(row)
            return {}
        except:
            return {}

def insert_entry(data: dict) -> int:
    """Insert new entry, returns new ID"""
    data['created_at'] = datetime.now().isoformat()
    data['updated_at'] = datetime.now().isoformat()
    
    if is_cloud():
        add_entry_to_state(data)
        return len(st.session_state.get('new_entries', [])) + 1000  # Fake ID
    else:
        conn = get_connection()
        if conn is None:
            return -1
        try:
            cursor = conn.cursor()
            columns = ', '.join(data.keys())
            placeholders = ', '.join(['?' for _ in data])
            sql = f"INSERT INTO coffee_archive ({columns}) VALUES ({placeholders})"
            cursor.execute(sql, list(data.values()))
            new_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return new_id
        except Exception as e:
            st.error(f"Insert failed: {e}")
            return -1

def update_entry(entry_id: int, data: dict) -> bool:
    """Update existing entry"""
    data['updated_at'] = datetime.now().isoformat()
    
    if is_cloud():
        # In cloud, update in session_state if exists, else add
        if 'new_entries' in st.session_state:
            for i, entry in enumerate(st.session_state['new_entries']):
                if entry.get('id') == entry_id:
                    st.session_state['new_entries'][i].update(data)
                    return True
        # If not in session, add as new
        data['id'] = entry_id
        add_entry_to_state(data)
        return True
    else:
        conn = get_connection()
        if conn is None:
            return False
        try:
            cursor = conn.cursor()
            set_clause = ', '.join([f"{k} = ?" for k in data.keys()])
            sql = f"UPDATE coffee_archive SET {set_clause} WHERE id = ?"
            cursor.execute(sql, list(data.values()) + [entry_id])
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            st.error(f"Update failed: {e}")
            return False

def delete_entry(entry_id: int) -> bool:
    """Delete entry"""
    if is_cloud():
        if 'new_entries' in st.session_state:
            st.session_state['new_entries'] = [
                e for e in st.session_state['new_entries'] 
                if e.get('id') != entry_id
            ]
        return True
    else:
        conn = get_connection()
        if conn is None:
            return False
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM coffee_archive WHERE id = ?", (entry_id,))
            conn.commit()
            conn.close()
            return True
        except:
            return False

def get_entries_count() -> int:
    """Get total count"""
    if is_cloud():
        return len(get_all_entries_merged())
    conn = get_connection()
    if conn is None:
        return 0
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM coffee_archive")
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def search_entries(query: str) -> pd.DataFrame:
    """Search entries"""
    return get_all_entries({'search': query})

# Dropdown data
def get_unique_cafes() -> list:
    df = get_all_entries()
    if df.empty:
        return ['Seniman Coffee Studio', 'Kyuukei Coffee', 'Subko Coffee Roasters', 
                'Grey Soul Coffee Roasters', 'Apartment Coffee', 'Agora Coffee',
                'Tiong Hoe', 'Maxi Coffee Bar', 'Asylum Coffeehouse', 'Lume Cafe',
                'Nylon Coffee Roasters', 'Pocket by Flip', 'Alchemist', 'Kurasu',
                'The Community Coffee', 'FLUID']
    cafes = df['cafe_name'].dropna().unique().tolist()
    return sorted([c for c in cafes if c and c != 'Unknown'])

def get_unique_cities() -> list:
    df = get_all_entries()
    if df.empty:
        return ['Singapore', 'Ubud, Bali', 'Mumbai', 'Johor Bahru']
    cities = df['city'].dropna().unique().tolist()
    return sorted([c for c in cities if c and c != 'Unknown'])

def get_unique_varietals() -> list:
    df = get_all_entries()
    if df.empty:
        return ['Geisha', 'Gesha', 'Sudan Rume', 'Wush Wush', 'Heirloom', 'Arara', 
                'Typica', 'Typica Mejorado', 'Marshell', 'Hybrid Laurina', 'Parainema',
                'Catucai 24/137', 'Castillo', 'Pacamara', 'Sidra', 'Bourbon', 'Local Varietals']
    vars = df['varietal'].dropna().unique().tolist()
    return sorted([v for v in vars if v and v != 'Unknown'])

def get_unique_grinders() -> list:
    df = get_all_entries()
    if df.empty:
        return ['Mahlkönig EK43 (98mm flat)', 'Mahlkönig EK43S (98mm flat)',
                'Mahlkönig CORE (54mm flat)', 'Mahlkönig EK Omnia',
                'Timemore Sculptor 078 (SSP 78mm)', 'Option-O Lagom P64 (SSP 64mm)',
                '120mm Hybrid Burr']
    grinds = df['grinder'].dropna().unique().tolist()
    return sorted([g for g in grinds if g and g != 'Unknown'])

def get_cafe_city_map() -> dict:
    df = get_all_entries()
    if df.empty:
        return {'Seniman Coffee Studio': 'Ubud, Bali', 'Kyuukei Coffee': 'Singapore',
                'Subko Coffee Roasters': 'Mumbai', 'Grey Soul Coffee Roasters': 'Mumbai',
                'Apartment Coffee': 'Singapore', 'Agora Coffee': 'Singapore',
                'Tiong Hoe': 'Singapore', 'Maxi Coffee Bar': 'Singapore',
                'Asylum Coffeehouse': 'Singapore', 'Lume Cafe': 'Singapore',
                'Nylon Coffee Roasters': 'Singapore', 'Pocket by Flip': 'Singapore',
                'Alchemist': 'Singapore', 'Kurasu': 'Singapore',
                'The Community Coffee': 'Singapore', 'FLUID': 'Singapore'}
    mapping = {}
    for _, row in df.iterrows():
        if row['cafe_name'] and row['city']:
            mapping[row['cafe_name']] = row['city']
    return mapping

def get_cafe_grinder_map() -> dict:
    df = get_all_entries()
    if df.empty:
        return {}
    mapping = {}
    for cafe in df['cafe_name'].unique():
        cafe_df = df[df['cafe_name'] == cafe].dropna(subset=['grinder'])
        if not cafe_df.empty:
            mapping[cafe] = cafe_df.iloc[-1]['grinder']
    return mapping

def get_entries_by_cafe(cafe: str) -> pd.DataFrame:
    df = get_all_entries()
    if df.empty:
        return pd.DataFrame()
    return df[df['cafe_name'] == cafe].sort_values('date', ascending=False)

# Analytics
def get_process_counts() -> pd.DataFrame:
    df = get_all_entries()
    if df.empty:
        return pd.DataFrame({'process': ['Washed', 'Natural', 'Anaerobic'], 'count': [12, 8, 5]})
    return df['process'].value_counts().reset_index().rename(columns={'index': 'process', 'process': 'count'})

def get_origin_counts() -> pd.DataFrame:
    df = get_all_entries()
    if df.empty:
        return pd.DataFrame({'origin': ['Colombia', 'Brazil', 'Ethiopia'], 'count': [5, 4, 3]})
    # Approximate origin from coffee_name or city
    df['origin'] = df['coffee_name'].apply(lambda x: str(x).split()[0] if pd.notna(x) else 'Unknown')
    return df['origin'].value_counts().reset_index().rename(columns={'index': 'origin', 'origin': 'count'})

def get_entries_by_month() -> pd.DataFrame:
    df = get_all_entries()
    if df.empty:
        months = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05']
        return pd.DataFrame({'month': months, 'count': [3, 2, 5, 12, 9]})
    df['month'] = pd.to_datetime(df['date'], errors='coerce').dt.to_period('M').astype(str)
    return df.groupby('month').size().reset_index(name='count')

def get_top_entries(n=5) -> pd.DataFrame:
    df = get_all_entries()
    if df.empty or 'sentiment_score' not in df.columns:
        return pd.DataFrame()
    return df.nlargest(n, 'sentiment_score')[['id', 'coffee_name', 'cafe_name', 'date', 'sentiment_score', 'your_verdict']]

def get_palate_scores() -> dict:
    # Simulated palate scores based on archive analysis
    return {
        'Acid': 8.2,
        'Body': 7.5,
        'Sweetness': 8.8,
        'Clarity': 9.1,
        'Complexity': 8.4
    }

def get_grinder_counts() -> pd.DataFrame:
    df = get_all_entries()
    if df.empty:
        return pd.DataFrame({'grinder': ['EK43', 'CORE', 'Lagom P64'], 'count': [8, 5, 4]})
    return df['grinder'].value_counts().reset_index().rename(columns={'index': 'grinder', 'grinder': 'count'})

# Beans
def get_all_beans() -> pd.DataFrame:
    if is_cloud():
        if 'beans' not in st.session_state:
            st.session_state['beans'] = []
        return pd.DataFrame(st.session_state['beans'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM beans", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_bean(data: dict) -> int:
    data['created_at'] = datetime.now().isoformat()
    if is_cloud():
        if 'beans' not in st.session_state:
            st.session_state['beans'] = []
        data['id'] = len(st.session_state['beans']) + 1
        st.session_state['beans'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO beans ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

def update_bean_weight(bean_id: int, new_weight: int) -> bool:
    if is_cloud():
        if 'beans' in st.session_state:
            for i, b in enumerate(st.session_state['beans']):
                if b.get('id') == bean_id:
                    st.session_state['beans'][i]['weight_remaining_g'] = new_weight
                    return True
        return False
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE beans SET weight_remaining_g = ? WHERE id = ?", (new_weight, bean_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def finish_bean(bean_id: int, rating: int) -> bool:
    if is_cloud():
        if 'beans' in st.session_state:
            for i, b in enumerate(st.session_state['beans']):
                if b.get('id') == bean_id:
                    st.session_state['beans'][i]['is_finished'] = 1
                    st.session_state['beans'][i]['final_rating'] = rating
                    st.session_state['beans'][i]['finished_date'] = datetime.now().isoformat()
                    return True
        return False
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("""UPDATE beans SET is_finished = 1, final_rating = ?, 
                          finished_date = ? WHERE id = ?""", 
                       (rating, datetime.now().isoformat(), bean_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def get_all_brew_sessions() -> pd.DataFrame:
    if is_cloud():
        if 'brew_sessions' not in st.session_state:
            st.session_state['brew_sessions'] = []
        return pd.DataFrame(st.session_state['brew_sessions'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM brew_sessions", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_brew_session(data: dict) -> int:
    if is_cloud():
        if 'brew_sessions' not in st.session_state:
            st.session_state['brew_sessions'] = []
        data['id'] = len(st.session_state['brew_sessions']) + 1
        st.session_state['brew_sessions'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO brew_sessions ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

# Wishlist
def get_wishlist() -> pd.DataFrame:
    if is_cloud():
        if 'wishlist' not in st.session_state:
            st.session_state['wishlist'] = []
        return pd.DataFrame(st.session_state['wishlist'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM wishlist", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_wishlist_item(data: dict) -> int:
    if is_cloud():
        if 'wishlist' not in st.session_state:
            st.session_state['wishlist'] = []
        data['id'] = len(st.session_state['wishlist']) + 1
        st.session_state['wishlist'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO wishlist ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

def mark_purchased(item_id: int) -> bool:
    if is_cloud():
        if 'wishlist' in st.session_state:
            for i, item in enumerate(st.session_state['wishlist']):
                if item.get('id') == item_id:
                    st.session_state['wishlist'][i]['is_purchased'] = 1
                    st.session_state['wishlist'][i]['purchased_date'] = datetime.now().isoformat()
                    return True
        return False
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE wishlist SET is_purchased = 1, purchased_date = ? WHERE id = ?",
                       (datetime.now().isoformat(), item_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def delete_wishlist_item(item_id: int) -> bool:
    if is_cloud():
        if 'wishlist' in st.session_state:
            st.session_state['wishlist'] = [w for w in st.session_state['wishlist'] if w.get('id') != item_id]
        return True
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM wishlist WHERE id = ?", (item_id,))
        conn.commit()
        conn.close()
        return True
    except:
        return False

# Goals
def get_all_goals() -> pd.DataFrame:
    if is_cloud():
        if 'goals' not in st.session_state:
            st.session_state['goals'] = []
        return pd.DataFrame(st.session_state['goals'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM goals", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_goal(data: dict) -> int:
    if is_cloud():
        if 'goals' not in st.session_state:
            st.session_state['goals'] = []
        data['id'] = len(st.session_state['goals']) + 1
        st.session_state['goals'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO goals ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

def complete_goal(goal_id: int) -> bool:
    if is_cloud():
        if 'goals' in st.session_state:
            for i, g in enumerate(st.session_state['goals']):
                if g.get('id') == goal_id:
                    st.session_state['goals'][i]['is_complete'] = 1
                    st.session_state['goals'][i]['complete_date'] = datetime.now().isoformat()
                    return True
        return False
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("UPDATE goals SET is_complete = 1, complete_date = ? WHERE id = ?",
                       (datetime.now().isoformat(), goal_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def get_goals_by_category() -> dict:
    goals = get_all_goals()
    if goals.empty:
        return {}
    return goals.groupby('category').apply(lambda x: x.to_dict('records')).to_dict()

# Journal
def get_all_journal_entries() -> pd.DataFrame:
    if is_cloud():
        if 'journal_entries' not in st.session_state:
            st.session_state['journal_entries'] = []
        return pd.DataFrame(st.session_state['journal_entries'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM journal_entries ORDER BY created_at DESC", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_journal_entry(data: dict) -> int:
    data['created_at'] = datetime.now().isoformat()
    data['updated_at'] = datetime.now().isoformat()
    if is_cloud():
        if 'journal_entries' not in st.session_state:
            st.session_state['journal_entries'] = []
        data['id'] = len(st.session_state['journal_entries']) + 1
        st.session_state['journal_entries'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO journal_entries ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

def update_journal_entry(entry_id: int, data: dict) -> bool:
    data['updated_at'] = datetime.now().isoformat()
    if is_cloud():
        if 'journal_entries' in st.session_state:
            for i, j in enumerate(st.session_state['journal_entries']):
                if j.get('id') == entry_id:
                    st.session_state['journal_entries'][i].update(data)
                    return True
        return False
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        set_clause = ', '.join([f"{k} = ?" for k in data.keys()])
        sql = f"UPDATE journal_entries SET {set_clause} WHERE id = ?"
        cursor.execute(sql, list(data.values()) + [entry_id])
        conn.commit()
        conn.close()
        return True
    except:
        return False

def delete_journal_entry(entry_id: int) -> bool:
    if is_cloud():
        if 'journal_entries' in st.session_state:
            st.session_state['journal_entries'] = [j for j in st.session_state['journal_entries'] if j.get('id') != entry_id]
        return True
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM journal_entries WHERE id = ?", (entry_id,))
        conn.commit()
        conn.close()
        return True
    except:
        return False

# Saved Recipes
def get_saved_recipes() -> pd.DataFrame:
    if is_cloud():
        if 'saved_recipes' not in st.session_state:
            st.session_state['saved_recipes'] = []
        return pd.DataFrame(st.session_state['saved_recipes'])
    conn = get_connection()
    if conn is None:
        return pd.DataFrame()
    try:
        df = pd.read_sql_query("SELECT * FROM saved_recipes", conn)
        conn.close()
        return df
    except:
        return pd.DataFrame()

def insert_saved_recipe(data: dict) -> int:
    data['created_at'] = datetime.now().isoformat()
    if is_cloud():
        if 'saved_recipes' not in st.session_state:
            st.session_state['saved_recipes'] = []
        data['id'] = len(st.session_state['saved_recipes']) + 1
        st.session_state['saved_recipes'].append(data)
        return data['id']
    conn = get_connection()
    if conn is None:
        return -1
    try:
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        sql = f"INSERT INTO saved_recipes ({columns}) VALUES ({placeholders})"
        cursor.execute(sql, list(data.values()))
        new_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return new_id
    except:
        return -1

def delete_saved_recipe(recipe_id: int) -> bool:
    if is_cloud():
        if 'saved_recipes' in st.session_state:
            st.session_state['saved_recipes'] = [r for r in st.session_state['saved_recipes'] if r.get('id') != recipe_id]
        return True
    conn = get_connection()
    if conn is None:
        return False
    try:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM saved_recipes WHERE id = ?", (recipe_id,))
        conn.commit()
        conn.close()
        return True
    except:
        return False