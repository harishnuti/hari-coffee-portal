import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import (
    get_all_beans, insert_bean, update_bean_weight, finish_bean,
    get_all_brew_sessions, insert_brew_session, get_wishlist,
    insert_wishlist_item, mark_purchased, delete_wishlist_item
)
from components.charts import render_degassing_gauge

st.set_page_config(page_title="Bean Tracker - Hari's Coffee Archive", layout="wide")

st.title("🫘 Bean Tracker")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📦 Active Bags", "➕ Add New Bag", "☕ Brew Sessions", 
    "⭐ Wishlist", "📊 Statistics"
])

with tab1:
    st.subheader("Active Bags (Sorted by Optimal Window)")
    
    beans = get_all_beans()
    if beans.empty:
        st.info("No beans tracked yet. Add your first bag!")
    else:
        active = beans[beans['is_finished'] == 0].copy()
        if active.empty:
            st.info("All bags finished. Add new ones!")
        else:
            # Calculate days since roast
            def get_days(row):
                try:
                    roast = datetime.fromisoformat(row['roast_date'])
                    return (datetime.now() - roast).days
                except:
                    return 18
            
            active['days_since_roast'] = active.apply(get_days, axis=1)
            
            # Sort: optimal first (15-25 days)
            def sort_key(row):
                d = row['days_since_roast']
                if 15 <= d <= 25:
                    return 0
                elif 8 <= d <= 14:
                    return 1
                elif 26 <= d <= 35:
                    return 2
                else:
                    return 3
            
            active['sort_key'] = active.apply(sort_key, axis=1)
            active = active.sort_values('sort_key')
            
            for _, bean in active.iterrows():
                with st.container():
                    col1, col2, col3 = st.columns([3, 2, 2])
                    
                    with col1:
                        st.markdown(f"### {bean.get('coffee_name', 'Unknown')}")
                        st.caption(f"{bean.get('roaster', '')} • {bean.get('process', '')}")
                    
                    with col2:
                        days = bean['days_since_roast']
                        status = "OPTIMAL" if 15 <= days <= 25 else ("Approaching" if days < 15 else "Fading")
                        color = "#4ade80" if status == "OPTIMAL" else "#fb923c"
                        st.markdown(f"<span style='color:{color}'>**{status}**</span> • {days} days", unsafe_allow_html=True)
                        st.progress(min(days / 45, 1.0))
                    
                    with col3:
                        remaining = bean.get('weight_remaining_g', bean.get('weight_g', 250))
                        st.metric("Remaining", f"{remaining}g")
                        cost_per_brew = round(bean.get('price_sgd', 25) / (bean.get('weight_g', 250) / 15), 2)
                        st.caption(f"~SGD {cost_per_brew}/brew")
                    
                    col1, col2, col3 = st.columns(3)
                    if col1.button("☕ Brew Now", key=f"brew_{bean.get('id')}"):
                        st.session_state['brew_bean_id'] = bean.get('id')
                        st.session_state['brew_bean_name'] = bean.get('coffee_name')
                        st.rerun()
                    
                    if col2.button("✅ Finish Bag", key=f"finish_{bean.get('id')}"):
                        rating = st.slider("Final Rating", 1, 5, 4, key=f"fin_rating_{bean.get('id')}")
                        if st.button("Confirm Finish", key=f"confirm_finish_{bean.get('id')}"):
                            finish_bean(bean.get('id'), rating)
                            st.success("Bag marked as finished!")
                            st.rerun()
                    
                    if col3.button("⚖️ Update Weight", key=f"weight_{bean.get('id')}"):
                        new_w = st.number_input("New weight (g)", value=int(remaining), key=f"new_w_{bean.get('id')}")
                        if st.button("Save Weight", key=f"save_w_{bean.get('id')}"):
                            update_bean_weight(bean.get('id'), new_w)
                            st.success("Weight updated!")
                            st.rerun()
                    
                    st.divider()

with tab2:
    st.subheader("Add New Bean Bag")
    
    with st.form("new_bean_form"):
        col1, col2 = st.columns(2)
        with col1:
            roaster = st.text_input("Roaster")
            coffee_name = st.text_input("Coffee Name")
            varietal = st.selectbox("Varietal", ['Geisha', 'Gesha', 'Sudan Rume', 'Heirloom', 'Arara', 'Other'])
        with col2:
            process = st.selectbox("Process", ['Washed', 'Natural', 'Honey', 'Anaerobic'])
            roast_date = st.date_input("Roast Date")
            purchase_date = st.date_input("Purchase Date")
        
        col1, col2 = st.columns(2)
        with col1:
            weight = st.number_input("Weight (g)", value=250)
            price = st.number_input("Price (SGD)", value=25.0, step=0.5)
        with col2:
            where_bought = st.text_input("Where Bought")
        
        submitted = st.form_submit_button("➕ Add Bean")
        
        if submitted:
            data = {
                'roaster': roaster,
                'coffee_name': coffee_name,
                'varietal': varietal,
                'process': process,
                'roast_date': str(roast_date),
                'purchase_date': str(purchase_date),
                'weight_g': int(weight),
                'weight_remaining_g': int(weight),
                'price_sgd': price,
                'where_bought': where_bought,
                'is_finished': 0
            }
            new_id = insert_bean(data)
            st.success(f"Bean #{new_id} added successfully!")
            st.balloons()

with tab3:
    st.subheader("Brew Sessions Log")
    
    if 'brew_bean_id' in st.session_state:
        st.info(f"Brewing: {st.session_state.get('brew_bean_name', '')}")
        with st.form("brew_form"):
            col1, col2 = st.columns(2)
            with col1:
                brew_method = st.selectbox("Brew Method", ['V60', 'Flat-Bottom', 'xBloom', 'Espresso'])
                dose = st.number_input("Dose (g)", value=15.0)
                yield_g = st.number_input("Yield (g)", value=225.0)
            with col2:
                grinder = st.text_input("Grinder", value="Mahlkönig CORE")
                temp = st.number_input("Temp (°C)", value=92)
                rating = st.slider("Rating", 1, 5, 4)
            
            tasting = st.text_area("Tasting Note")
            hot_n = st.text_input("Hot Note")
            mid_n = st.text_input("Mid Note")
            cool_n = st.text_input("Cool Note")
            
            if st.form_submit_button("Log Brew Session"):
                data = {
                    'bean_id': st.session_state['brew_bean_id'],
                    'session_date': datetime.now().isoformat(),
                    'brew_method': brew_method,
                    'dose_g': dose,
                    'yield_g': yield_g,
                    'ratio': f"1:{yield_g/dose:.1f}",
                    'grinder': grinder,
                    'temp_c': int(temp),
                    'tasting_note': tasting,
                    'rating': rating,
                    'hot_note': hot_n,
                    'mid_note': mid_n,
                    'cool_note': cool_n
                }
                insert_brew_session(data)
                # Update weight
                update_bean_weight(st.session_state['brew_bean_id'], 
                                   int(st.session_state.get('current_weight', 250) - 15))
                st.success("Brew session logged!")
                del st.session_state['brew_bean_id']
                st.rerun()
    
    sessions = get_all_brew_sessions()
    if not sessions.empty:
        st.dataframe(sessions, use_container_width=True)
    else:
        st.info("No brew sessions logged yet.")

with tab4:
    st.subheader("Wishlist")
    
    wishlist = get_wishlist()
    
    if not wishlist.empty:
        for _, item in wishlist.iterrows():
            with st.container():
                col1, col2 = st.columns([4, 1])
                col1.markdown(f"**{item.get('coffee_name')}** — {item.get('match_percent')}% match")
                col1.caption(item.get('why_fits', '')[:100])
                if col2.button("✅ Purchased", key=f"buy_{item.get('id')}"):
                    mark_purchased(item.get('id'))
                    st.success("Marked as purchased! Add to Bean Tracker.")
                    st.rerun()
                if col2.button("🗑️ Remove", key=f"del_wish_{item.get('id')}"):
                    delete_wishlist_item(item.get('id'))
                    st.rerun()
    
    with st.expander("➕ Add to Wishlist"):
        with st.form("wishlist_form"):
            cname = st.text_input("Coffee Name")
            origin = st.text_input("Origin")
            proc = st.text_input("Process")
            var = st.text_input("Varietal")
            match = st.slider("Match %", 50, 100, 85)
            why = st.text_area("Why it fits")
            price = st.text_input("Est. Price")
            where = st.text_input("Where to find")
            
            if st.form_submit_button("Add to Wishlist"):
                insert_wishlist_item({
                    'coffee_name': cname, 'origin': origin, 'process': proc,
                    'varietal': var, 'match_percent': match, 'why_fits': why,
                    'estimated_price': price, 'where_to_find': where
                })
                st.success("Added to wishlist!")
                st.rerun()

with tab5:
    st.subheader("Bean Statistics")
    
    beans = get_all_beans()
    if not beans.empty:
        total_spent = beans['price_sgd'].sum()
        st.metric("Total Spent on Beans", f"SGD {total_spent:.2f}")
        
        sessions = get_all_brew_sessions()
        if not sessions.empty:
            st.metric("Total Brew Sessions Logged", len(sessions))
        
        st.bar_chart(beans.groupby('roaster')['price_sgd'].sum())
    else:
        st.info("Add beans to see statistics.")