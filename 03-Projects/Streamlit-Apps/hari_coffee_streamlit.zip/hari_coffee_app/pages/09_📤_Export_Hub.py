import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import get_all_entries_merged, get_entry_by_id, get_all_entries
from components.exporters import (
    generate_csv_line, generate_gemini_prompt, 
    generate_instagram_caption, generate_twitter_thread,
    generate_maps_review, generate_share_card
)

st.set_page_config(page_title="Export Hub - Hari's Coffee Archive", layout="wide")

st.title("📤 Export Hub")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📦 Archive Export", "🖼️ Gemini Prompts", "📱 Social Content",
    "📱 QR Recipe Cards", "💬 Share Cards"
])

with tab1:
    st.subheader("Export Archive as CSV / JSON")
    
    df = get_all_entries_merged()
    
    # Filters
    col1, col2 = st.columns(2)
    with col1:
        date_from = st.date_input("From Date", value=None)
    with col2:
        date_to = st.date_input("To Date", value=None)
    
    if date_from and date_to:
        df = df[(pd.to_datetime(df['date']) >= pd.to_datetime(date_from)) & 
                (pd.to_datetime(df['date']) <= pd.to_datetime(date_to))]
    
    st.caption(f"**{len(df)} entries** selected for export")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.download_button(
            "⬇️ Download CSV",
            data=df.to_csv(index=False),
            file_name="hari_coffee_archive_export.csv",
            mime="text/csv"
        )
    
    with col2:
        st.download_button(
            "⬇️ Download JSON",
            data=df.to_json(orient='records', indent=2),
            file_name="hari_coffee_archive_export.json",
            mime="application/json"
        )
    
    st.dataframe(df.head(20), use_container_width=True)

with tab2:
    st.subheader("Generate Gemini Infographic Prompt")
    
    df = get_all_entries()
    if not df.empty:
        entry_list = [f"#{r.get('id')} — {r.get('coffee_name')} @ {r.get('cafe_name')}" for _, r in df.iterrows()]
        selected = st.selectbox("Select entry", entry_list)
        entry_id = int(selected.split('—')[0].replace('#', '').strip())
        entry = get_entry_by_id(entry_id)
        
        prompt = generate_gemini_prompt(entry)
        st.text_area("Gemini Prompt (copy to Gemini)", prompt, height=400)
        
        if st.button("📋 Copy Prompt"):
            st.code(prompt)
            st.success("Prompt ready to copy!")
        
        st.subheader("Batch: All Entries")
        if st.button("Generate All Prompts"):
            all_prompts = "\n\n---\n\n".join([generate_gemini_prompt(get_entry_by_id(r['id'])) for _, r in df.iterrows()])
            st.download_button(
                "⬇️ Download All Prompts",
                data=all_prompts,
                file_name="gemini_prompts_all.txt"
            )

with tab3:
    st.subheader("Social Media Content Generator")
    
    df = get_all_entries()
    if not df.empty:
        entry_list = [f"#{r.get('id')} — {r.get('coffee_name')}" for _, r in df.iterrows()]
        selected = st.selectbox("Select entry for social content", entry_list, key="social_entry")
        entry_id = int(selected.split('—')[0].replace('#', '').strip())
        entry = get_entry_by_id(entry_id)
        
        social_tab1, social_tab2, social_tab3 = st.tabs(["Instagram", "Twitter/X Thread", "Google Maps"])
        
        with social_tab1:
            tone = st.radio("Tone", ["Technical", "Balanced", "Accessible"], horizontal=True)
            caption = generate_instagram_caption(entry, tone.lower())
            st.text_area("Instagram Caption", caption, height=250)
            st.caption("Copy and paste to Instagram. 15 hashtags included.")
        
        with social_tab2:
            tweets = generate_twitter_thread(entry)
            for i, tweet in enumerate(tweets, 1):
                st.text_area(f"Tweet {i}/8", tweet, height=80, key=f"tweet_{i}")
        
        with social_tab3:
            variant = st.radio("Variant", ["Technical", "Accessible", "Short"], horizontal=True, key="maps_var")
            review = generate_maps_review(entry, variant.lower())
            st.text_area("Google Maps Review", review, height=200)

with tab4:
    st.subheader("QR Recipe Cards (Text-based)")
    
    df = get_all_entries()
    if not df.empty:
        selected_entries = st.multiselect(
            "Select entries for recipe cards",
            [f"#{r.get('id')} {r.get('coffee_name')}" for _, r in df.iterrows()],
            default=[f"#{r.get('id')} {r.get('coffee_name')}" for _, r in df.head(5).iterrows()]
        )
        
        if st.button("Generate Recipe Cards"):
            cards = []
            for sel in selected_entries:
                eid = int(sel.split()[0].replace('#', ''))
                entry = get_entry_by_id(eid)
                card = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
☕ {entry.get('coffee_name')}
@ {entry.get('cafe_name')} • {entry.get('date')}

Brew: {entry.get('brew_method')} • {entry.get('ratio')}
Grinder: {entry.get('grinder', 'N/A')}
Temp: {entry.get('brew_temp', '92°C')}

Verdict: {entry.get('your_verdict', '')[:100]}...

Sentiment: {entry.get('sentiment_score', 8.0)}/10
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
                cards.append(card)
            
            all_cards = "\n\n".join(cards)
            st.download_button(
                "⬇️ Download Recipe Cards (TXT)",
                data=all_cards,
                file_name="recipe_cards.txt"
            )
            st.code(all_cards)

with tab5:
    st.subheader("Share Cards (WhatsApp / Telegram)")
    
    df = get_all_entries()
    if not df.empty:
        selected = st.selectbox("Select entry", 
            [f"#{r.get('id')} — {r.get('coffee_name')}" for _, r in df.iterrows()],
            key="share_entry")
        entry_id = int(selected.split('—')[0].replace('#', '').strip())
        entry = get_entry_by_id(entry_id)
        
        card = generate_share_card(entry)
        st.code(card, language=None)
        st.caption("Copy and paste directly to WhatsApp, Telegram, or Signal.")