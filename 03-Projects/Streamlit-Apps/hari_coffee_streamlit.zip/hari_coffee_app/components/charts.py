import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta

# Dark theme template for all charts
PLOTLY_TEMPLATE = {
    'layout': {
        'paper_bgcolor': '#0d0d0d',
        'plot_bgcolor': '#1a1a1a',
        'font': {'color': '#f5f5f5', 'size': 12},
        'colorway': ['#c9a84c', '#f5f5f5', '#4a7fc1', '#e05252', '#4ade80', '#fb923c', '#a78bfa'],
        'margin': {'l': 40, 'r': 40, 't': 40, 'b': 40},
        'hoverlabel': {'bgcolor': '#1a1a1a', 'font_color': '#f5f5f5'}
    }
}

def render_process_donut(df: pd.DataFrame) -> go.Figure:
    """Donut chart of process breakdown"""
    if df.empty or 'process' not in df.columns:
        processes = ['Washed', 'Natural', 'Anaerobic', 'Honey', 'Co-ferment']
        counts = [12, 8, 5, 3, 3]
    else:
        proc_counts = df['process'].value_counts()
        processes = proc_counts.index.tolist()
        counts = proc_counts.values.tolist()
    
    fig = go.Figure(data=[go.Pie(
        labels=processes,
        values=counts,
        hole=0.55,
        marker=dict(colors=['#4a7fc1', '#fb923c', '#e05252', '#c9a84c', '#a78bfa']),
        textinfo='label+percent',
        textfont={'color': '#f5f5f5', 'size': 11}
    )])
    fig.update_layout(
        title="Process Distribution",
        template=PLOTLY_TEMPLATE,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=-0.2)
    )
    return fig

def render_origin_bar(df: pd.DataFrame) -> go.Figure:
    """Horizontal bar of entries by origin"""
    if df.empty:
        origins = ['Colombia', 'Brazil', 'Ethiopia', 'Panama', 'Peru', 'Ecuador', 'Kenya']
        counts = [6, 5, 4, 3, 3, 2, 2]
    else:
        # Approximate origin from coffee_name
        df = df.copy()
        df['origin'] = df['coffee_name'].apply(lambda x: str(x).split()[0] if pd.notna(x) else 'Unknown')
        origin_counts = df['origin'].value_counts().head(10)
        origins = origin_counts.index.tolist()
        counts = origin_counts.values.tolist()
    
    fig = go.Figure(go.Bar(
        x=counts,
        y=origins,
        orientation='h',
        marker_color='#c9a84c',
        text=counts,
        textposition='auto'
    ))
    fig.update_layout(
        title="Entries by Origin (Top 10)",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Number of Entries",
        yaxis_title="Origin"
    )
    return fig

def render_monthly_timeline(df: pd.DataFrame) -> go.Figure:
    """Line chart of audits per month Jan-May 2026"""
    if df.empty or 'date' not in df.columns:
        months = ['Jan 2026', 'Feb 2026', 'Mar 2026', 'Apr 2026', 'May 2026']
        counts = [3, 2, 5, 12, 9]
    else:
        df = df.copy()
        df['month'] = pd.to_datetime(df['date'], errors='coerce').dt.strftime('%b %Y')
        monthly = df.groupby('month').size().reindex(
            ['Jan 2026', 'Feb 2026', 'Mar 2026', 'Apr 2026', 'May 2026'], fill_value=0
        )
        months = monthly.index.tolist()
        counts = monthly.values.tolist()
    
    fig = go.Figure(go.Scatter(
        x=months,
        y=counts,
        mode='lines+markers',
        line=dict(color='#c9a84c', width=3),
        marker=dict(size=10, color='#c9a84c'),
        fill='tozeroy',
        fillcolor='rgba(201, 168, 76, 0.2)'
    ))
    fig.update_layout(
        title="Audit Activity Timeline (2026)",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Month",
        yaxis_title="Number of Audits"
    )
    return fig

def render_palate_radar(scores: dict) -> go.Figure:
    """Spider chart: Acid/Body/Sweetness/Clarity/Complexity"""
    categories = ['Acid', 'Body', 'Sweetness', 'Clarity', 'Complexity']
    values = [scores.get(c, 7.5) for c in categories]
    values += values[:1]  # Close the radar
    
    fig = go.Figure(go.Scatterpolar(
        r=values,
        theta=categories + [categories[0]],
        fill='toself',
        fillcolor='rgba(201, 168, 76, 0.4)',
        line=dict(color='#c9a84c', width=2)
    ))
    fig.update_layout(
        title="Palate Profile (Average)",
        template=PLOTLY_TEMPLATE,
        polar=dict(
            radialaxis=dict(visible=True, range=[0, 10], tickfont={'color': '#f5f5f5'}),
            angularaxis=dict(tickfont={'color': '#f5f5f5'})
        )
    )
    return fig

def render_price_scatter(df: pd.DataFrame) -> go.Figure:
    """Scatter: price vs rating, colored by city"""
    if df.empty or 'price_local' not in df.columns:
        return go.Figure()
    
    df = df.copy()
    # Parse price (assume SGD or numeric)
    df['price_num'] = pd.to_numeric(df['price_local'].astype(str).str.extract(r'(\d+\.?\d*)')[0], errors='coerce')
    df = df.dropna(subset=['price_num', 'rating'])
    
    if df.empty:
        return go.Figure()
    
    fig = px.scatter(
        df, x='price_num', y='rating', color='city',
        hover_data=['coffee_name', 'cafe_name'],
        color_discrete_sequence=['#c9a84c', '#4a7fc1', '#e05252', '#4ade80', '#fb923c']
    )
    fig.update_layout(
        title="Price vs Rating by City",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Price (SGD)",
        yaxis_title="Rating (1-5)"
    )
    return fig

def render_grinder_bar(df: pd.DataFrame) -> go.Figure:
    """Horizontal bar: grinder usage frequency"""
    if df.empty or 'grinder' not in df.columns:
        grinders = ['EK43 (98mm)', 'CORE (54mm)', 'Lagom P64', 'EK Omnia', 'Sculptor 078']
        counts = [8, 5, 4, 3, 3]
    else:
        g_counts = df['grinder'].value_counts().head(8)
        grinders = [g[:25] + '...' if len(str(g)) > 25 else g for g in g_counts.index]
        counts = g_counts.values.tolist()
    
    fig = go.Figure(go.Bar(
        x=counts,
        y=grinders,
        orientation='h',
        marker_color='#4a7fc1'
    ))
    fig.update_layout(
        title="Grinder Usage Frequency",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Times Used"
    )
    return fig

def render_top_entries_bar(df: pd.DataFrame) -> go.Figure:
    """Bar: top entries by sentiment score"""
    if df.empty or 'sentiment_score' not in df.columns:
        return go.Figure()
    
    top = df.nlargest(8, 'sentiment_score')[['coffee_name', 'sentiment_score']]
    
    fig = go.Figure(go.Bar(
        x=top['sentiment_score'],
        y=top['coffee_name'].str[:30],
        orientation='h',
        marker_color='#c9a84c'
    ))
    fig.update_layout(
        title="Top Entries by Sentiment Score",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Sentiment Score (0-10)"
    )
    return fig

def render_dose_yield_scatter(df: pd.DataFrame) -> go.Figure:
    """Scatter: dose vs yield, colored by brew method"""
    if df.empty or 'dose_g' not in df.columns or 'yield_g' not in df.columns:
        return go.Figure()
    
    df = df.copy()
    df = df.dropna(subset=['dose_g', 'yield_g'])
    if df.empty:
        return go.Figure()
    
    fig = px.scatter(
        df, x='dose_g', y='yield_g', color='brew_method',
        hover_data=['coffee_name', 'cafe_name'],
        color_discrete_sequence=PLOTLY_TEMPLATE['layout']['colorway']
    )
    fig.update_layout(
        title="Dose vs Yield by Brew Method",
        template=PLOTLY_TEMPLATE,
        xaxis_title="Dose (g)",
        yaxis_title="Yield (g)"
    )
    return fig

def render_world_map(df: pd.DataFrame) -> go.Figure:
    """Choropleth/scatter_geo: origin markers"""
    # Hardcoded coordinates for origins in archive
    origin_coords = {
        'Colombia': {'lat': 4.57, 'lon': -74.3, 'count': 6},
        'Brazil': {'lat': -14.23, 'lon': -51.92, 'count': 5},
        'Ethiopia': {'lat': 9.14, 'lon': 40.49, 'count': 4},
        'Panama': {'lat': 8.53, 'lon': -80.78, 'count': 3},
        'Peru': {'lat': -9.19, 'lon': -75.01, 'count': 3},
        'Ecuador': {'lat': -1.83, 'lon': -78.18, 'count': 2},
        'Kenya': {'lat': -1.29, 'lon': 36.82, 'count': 2},
        'Nicaragua': {'lat': 12.86, 'lon': -85.21, 'count': 2},
        'Honduras': {'lat': 15.2, 'lon': -86.24, 'count': 2},
        'El Salvador': {'lat': 13.79, 'lon': -88.89, 'count': 1},
        'Indonesia': {'lat': -0.79, 'lon': 113.92, 'count': 2},
        'India': {'lat': 20.59, 'lon': 78.96, 'count': 1}
    }
    
    if not df.empty and 'coffee_name' in df.columns:
        df = df.copy()
        df['origin'] = df['coffee_name'].apply(lambda x: str(x).split()[0] if pd.notna(x) else 'Unknown')
        actual_counts = df['origin'].value_counts().to_dict()
        for origin in origin_coords:
            if origin in actual_counts:
                origin_coords[origin]['count'] = actual_counts[origin]
    
    lats = [c['lat'] for c in origin_coords.values()]
    lons = [c['lon'] for c in origin_coords.values()]
    texts = [f"{o}: {c['count']} entries" for o, c in origin_coords.items()]
    sizes = [max(8, min(25, c['count'] * 3)) for c in origin_coords.values()]
    
    fig = go.Figure(go.Scattergeo(
        lat=lats,
        lon=lons,
        text=texts,
        mode='markers',
        marker=dict(
            size=sizes,
            color='#c9a84c',
            line=dict(width=1, color='#f5f5f5')
        )
    ))
    fig.update_layout(
        title="Coffee Origins Explored",
        template=PLOTLY_TEMPLATE,
        geo=dict(
            showland=True,
            landcolor='#1a1a1a',
            showocean=True,
            oceancolor='#0d0d0d',
            showcountries=True,
            countrycolor='#333',
            projection_type='natural earth'
        )
    )
    return fig

def render_degassing_gauge(roast_date: str) -> go.Figure:
    """Gauge chart showing degassing window status"""
    try:
        roast_dt = datetime.fromisoformat(roast_date) if 'T' in roast_date else datetime.strptime(roast_date, '%Y-%m-%d')
        days = (datetime.now() - roast_dt).days
    except:
        days = 18  # Default
    
    if days < 0:
        days = 0
    
    # Color based on window: 0-7 red, 8-14 yellow, 15-25 green, 26-35 yellow, 36+ red
    if days <= 7:
        color = '#e05252'
        status = "Too Fresh"
    elif days <= 14:
        color = '#fb923c'
        status = "Approaching Peak"
    elif days <= 25:
        color = '#4ade80'
        status = "OPTIMAL WINDOW"
    elif days <= 35:
        color = '#fb923c'
        status = "Fading"
    else:
        color = '#e05252'
        status = "Past Peak"
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=days,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': f"Days Since Roast<br><span style='font-size:14px'>{status}</span>"},
        gauge={
            'axis': {'range': [None, 45], 'tickcolor': '#f5f5f5'},
            'bar': {'color': color},
            'steps': [
                {'range': [0, 7], 'color': '#3d1a1a'},
                {'range': [7, 14], 'color': '#3d2a1a'},
                {'range': [14, 25], 'color': '#1a3d1a'},
                {'range': [25, 35], 'color': '#3d2a1a'},
                {'range': [35, 45], 'color': '#3d1a1a'}
            ],
            'threshold': {'line': {'color': '#c9a84c', 'width': 4}, 'thickness': 0.75, 'value': 20}
        },
        number={'suffix': " days", 'font': {'color': '#f5f5f5'}}
    ))
    fig.update_layout(
        template=PLOTLY_TEMPLATE,
        height=280
    )
    return fig