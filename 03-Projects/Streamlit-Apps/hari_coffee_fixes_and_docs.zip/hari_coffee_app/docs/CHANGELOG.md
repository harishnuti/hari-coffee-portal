# Changelog — Hari's Coffee Archive 2026

All notable changes to this project will be documented in this file.

---

## v1.0.1 — Bug Fix Release (20 May 2026)

### Fixed (per QA Audit)
- **BUG 1 (Critical):** `calculate_sentiment` ImportError — Function now lives in `database/queries.py` (with identical implementation in `seed.py` for backward compatibility). All components now import successfully.
- **BUG 2 (Critical):** Missing `seed_database` alias — Added `seed_database = seed_from_csv` at bottom of `database/seed.py`.
- **BUG 3 (Critical):** Missing `pages/10_⚙️_Settings.py` — Full implementation added with 7 sections (stats, import, backup, tools, cloud guide, danger zone, about).
- **BUG 4 (Minor):** `render_top_entries_bar` never called — Added to Dashboard between timeline and palate radar sections.

### Improved
- Dashboard now shows Top Rated Entries bar chart on load.
- Settings page includes one-click re-seed and re-initialize buttons.
- All 4 fixed Python files pass `python -m py_compile`.

### Architecture
- No changes to core dual-mode database design.
- All 10 pages now present and functional.

---

## v1.0.0 — Initial Release (20 May 2026)

### Added
- **10-page Streamlit application** with dark gold theme (#0d0d0d / #c9a84c)
- **Dual-mode database architecture:**
  - Local: Full SQLite with automatic `coffee_archive.db` creation
  - Cloud: CSV seed + `st.session_state` for writes (Export Hub persistence workflow)
- **Smart Entry Form** (7 sections):
  - Auto city/grinder fill from history
  - Live ratio calculator
  - Process descriptions
  - Sentiment scoring
  - Similar entries sidebar
  - Post-submit CSV line + Gemini prompt + Instagram caption generation
- **44 database query functions** covering full CRUD for 7 tables
- **10 Plotly chart functions** (all dark-themed):
  - Process donut, origin bar, monthly timeline, palate radar, price scatter, grinder bar, top entries bar, dose-yield scatter, world map, degassing gauge
- **6 export functions** in `components/exporters.py`:
  - `generate_csv_line`
  - `generate_gemini_prompt` (5-section cinematic)
  - `generate_instagram_caption` (3 tones)
  - `generate_twitter_thread` (8 tweets)
  - `generate_maps_review` (3 variants)
  - `generate_share_card`
- **Pre-seeded data:**
  - 31 real archive entries (Jan–May 2026)
  - 20 H2 2026 goals across 5 categories
  - 5 wishlist items with match percentages
- **Full Bean Tracker** (5 tabs): Active bags with degassing progress, Add new bag, Brew sessions, Wishlist, Statistics
- **Brew Lab** with recipe calculator and saved recipes
- **Origins Deep Map** with hardcoded terroir profiles for 12 origins
- **Journal** with mood tracking and optional archive linking
- **Export Hub** with CSV/JSON, Gemini batch, Social content, QR cards, Share cards
- **Settings page** (added in v1.0.1) with import, backup, restore, and danger zone
- **Custom CSS** with Playfair Display headings via Google Fonts CDN
- **README.md** with local + cloud deployment instructions

### Known Issues Fixed in v1.0.1
- All 4 issues listed above resolved.

### Technical Stack
- **Framework:** Streamlit 1.35+
- **Data:** pandas 2.0+
- **Charts:** Plotly 5.18+
- **Database:** SQLite (local) / CSV + session_state (cloud)
- **Theme:** Dark (#0d0d0d) with gold primary (#c9a84c)
- **Seed Data Source:** `hari_coffee_audit_master_2026.csv` (31 entries)

---

## Future Roadmap (v1.1+)

- Supabase backend for multi-device sync
- Netlify static portfolio site with embedded Gemini infographics
- Mobile-responsive improvements
- Blind tasting mode with origin prediction scoring
- Integration with Acaia scale API for real-time weight logging

**Maintained by:** Hari  
**Last Updated:** 20 May 2026 (v1.0.1)