import streamlit as st
import sys
import os
import json
import pandas as pd
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import is_cloud, get_connection
from database.queries import (
    get_entries_count, get_all_entries, get_all_beans,
    get_all_journal_entries, get_all_goals, get_wishlist,
    insert_entry, get_all_entries_merged
)
from database.schema import init_db
from database.seed import seed_database

st.set_page_config(page_title="Settings — Hari's Coffee Archive",
                   page_icon="⚙️", layout="wide")

st.title("⚙️ Settings & Data Management")

# ── SECTION 1: STATUS ─────────────────────────────
col1, col2, col3, col4 = st.columns(4)
col1.metric("Archive Entries", get_entries_count())
col2.metric("Beans Tracked", len(get_all_beans()))
col3.metric("Journal Entries", len(get_all_journal_entries()))
col4.metric("Goals", len(get_all_goals()))

st.divider()

if not is_cloud():
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'coffee_archive.db')
    if os.path.exists(db_path):
        db_size = os.path.getsize(db_path)
        st.caption(f"🗄️ Mode: **Local SQLite** · Database: {db_size/1024:.1f} KB · Path: {db_path}")
    else:
        st.caption("🗄️ Mode: Local SQLite · Database not yet initialised")
else:
    st.info("☁️ **Cloud Mode:** Running on Streamlit Cloud. "
            "New entries persist during this session only. "
            "Use Export below to download CSV and commit to GitHub for permanent storage.")

# ── SECTION 2: IMPORT ─────────────────────────────
st.subheader("📥 Import Entries from CSV")
uploaded = st.file_uploader("Upload CSV (must match 17-column master format)", type=['csv'])
if uploaded:
    try:
        df_import = pd.read_csv(uploaded)
        st.dataframe(df_import.head(5), use_container_width=True)
        st.caption(f"{len(df_import)} rows detected · {len(df_import.columns)} columns")
        
        if len(df_import.columns) != 17:
            st.error(f"Expected 17 columns, got {len(df_import.columns)}. Check your CSV format.")
        else:
            if st.button("⬆️ Import All Rows", type="primary"):
                count = 0
                for _, row in df_import.iterrows():
                    try:
                        insert_entry(row.to_dict())
                        count += 1
                    except Exception as e:
                        st.warning(f"Row skipped: {e}")
                st.success(f"✅ Imported {count} of {len(df_import)} entries")
                st.rerun()
    except Exception as e:
        st.error(f"Could not parse CSV: {e}")

# ── SECTION 3: EXPORT / BACKUP ────────────────────
st.divider()
st.subheader("💾 Backup & Export")

col1, col2, col3 = st.columns(3)

df_all = get_all_entries_merged()
timestamp = datetime.now().strftime("%Y%m%d_%H%M")

with col1:
    st.write("**Master CSV**")
    csv_data = df_all.to_csv(index=False)
    st.download_button(
        "⬇️ Download Master CSV",
        data=csv_data,
        file_name=f"hari_coffee_audit_master_{timestamp}.csv",
        mime="text/csv",
        use_container_width=True
    )

with col2:
    st.write("**Full JSON Backup**")
    backup = {
        "exported_at": datetime.now().isoformat(),
        "archive": df_all.to_dict(orient='records'),
        "beans": get_all_beans().to_dict(orient='records'),
        "journal": get_all_journal_entries().to_dict(orient='records'),
        "goals": get_all_goals().to_dict(orient='records'),
        "wishlist": get_wishlist().to_dict(orient='records'),
    }
    st.download_button(
        "⬇️ Download JSON Backup",
        data=json.dumps(backup, indent=2, default=str),
        file_name=f"hari_coffee_backup_{timestamp}.json",
        mime="application/json",
        use_container_width=True
    )

with col3:
    st.write("**Restore from Backup**")
    restore_file = st.file_uploader("Upload JSON backup", type=['json'],
                                    key="restore_uploader")
    if restore_file:
        try:
            backup_data = json.load(restore_file)
            count = len(backup_data.get('archive', []))
            st.caption(f"Found {count} archive entries in backup")
            if st.button("🔄 Restore Archive", use_container_width=True):
                for entry in backup_data.get('archive', []):
                    try:
                        insert_entry(entry)
                    except:
                        pass
                st.success(f"Restored {count} entries!")
                st.rerun()
        except Exception as e:
            st.error(f"Could not parse backup: {e}")

# ── SECTION 4: DATABASE TOOLS ─────────────────────
st.divider()
st.subheader("🔧 Database Tools")

col1, col2 = st.columns(2)

with col1:
    if st.button("🔄 Re-seed from CSV", help="Re-import the 31 master entries from the data CSV"):
        try:
            seed_database()
            st.success("✅ Re-seeded from master CSV")
            st.rerun()
        except Exception as e:
            st.error(f"Seed failed: {e}")

with col2:
    if st.button("🏗️ Re-initialise DB", help="Recreate all tables (safe — won't delete existing data)"):
        try:
            init_db()
            st.success("✅ Database tables verified/created")
        except Exception as e:
            st.error(f"Init failed: {e}")

# ── SECTION 5: DANGER ZONE ────────────────────────
st.divider()
with st.expander("⚠️ Danger Zone — Permanent Actions", expanded=False):
    st.error("**Warning:** The following actions cannot be undone.")
    
    st.write("**Clear Session State** (cloud mode only)")
    if st.button("🗑️ Clear New Entries from Session", type="secondary"):
        if 'new_entries' in st.session_state:
            st.session_state['new_entries'] = []
        st.success("Session cleared. Persisted CSV entries remain.")
    
    st.write("**Delete All Database Data** (local mode only)")
    if not is_cloud():
        confirm_text = st.text_input("Type DELETE to confirm permanent deletion:")
        if confirm_text == "DELETE":
            if st.button("🚨 Delete Everything", type="primary"):
                conn = get_connection()
                if conn:
                    tables = ['coffee_archive','beans','brew_sessions',
                              'wishlist','goals','journal_entries','saved_recipes']
                    for table in tables:
                        conn.execute(f"DELETE FROM {table}")
                    conn.commit()
                    conn.close()
                    st.success("All data deleted.")
                    st.rerun()
    else:
        st.info("Full delete not available in cloud mode.")

# ── SECTION 6: STREAMLIT CLOUD GUIDE ─────────────
st.divider()
st.subheader("☁️ Streamlit Cloud Deployment Guide")
with st.expander("How to deploy & keep data persistent"):
    st.markdown("""
    ### Deploying to Streamlit Cloud
    
    1. **Push to GitHub:**
       ```
       git init
       git add .
       git commit -m "Hari Coffee Archive App"
       git push origin main
       ```
    
    2. **Connect to Streamlit Cloud:**
       - Go to [share.streamlit.io](https://share.streamlit.io)
       - New app → select your GitHub repo
       - Main file path: `app.py`
       - Deploy
    
    3. **Keeping new entries persistent:**
       - Add entries during your session
       - Go to Export Hub → Download updated CSV
       - Replace `data/hari_coffee_master.csv` in your repo
       - Commit and push → Streamlit Cloud auto-redeploys
    
    4. **Your live URL:**
       ```
       https://[your-username]-coffee-archive.streamlit.app
       ```
    """)
