import streamlit as st
import pandas as pd
from datetime import datetime
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from database.queries import (
    get_all_journal_entries, insert_journal_entry, 
    update_journal_entry, delete_journal_entry, get_all_entries
)

st.set_page_config(page_title="Journal - Hari's Coffee Archive", layout="wide")

st.title("📝 Coffee Journal")

tab1, tab2 = st.tabs(["📰 Feed", "✍️ New Entry"])

with tab1:
    entries = get_all_journal_entries()
    
    if entries.empty:
        st.info("No journal entries yet. Start writing in the New Entry tab!")
    else:
        for _, entry in entries.iterrows():
            with st.container():
                col1, col2, col3 = st.columns([4, 1, 1])
                
                col1.subheader(entry.get('title', 'Untitled Entry'))
                col1.caption(f"{entry.get('created_at', '')[:10]} • {entry.get('word_count', 0)} words • {entry.get('mood', '')}")
                
                tags = entry.get('tags', '')
                if tags:
                    col1.caption(f"Tags: {tags}")
                
                body = entry.get('body', '')
                preview = body[:250] + "..." if len(body) > 250 else body
                col1.write(preview)
                
                if col2.button("✏️ Edit", key=f"edit_j_{entry.get('id')}"):
                    st.session_state['edit_journal_id'] = entry.get('id')
                    st.rerun()
                
                if col3.button("🗑️ Delete", key=f"del_j_{entry.get('id')}"):
                    if st.button("Confirm Delete", key=f"confirm_del_j_{entry.get('id')}"):
                        delete_journal_entry(entry.get('id'))
                        st.success("Entry deleted")
                        st.rerun()
                
                st.divider()
        
        # Edit mode
        if 'edit_journal_id' in st.session_state:
            eid = st.session_state['edit_journal_id']
            all_entries = get_all_journal_entries()
            current = all_entries[all_entries['id'] == eid].iloc[0] if not all_entries.empty else None
            
            if current is not None:
                with st.form("edit_journal"):
                    new_title = st.text_input("Title", value=current.get('title', ''))
                    new_mood = st.select_slider("Mood", 
                        options=["☕ Normal", "🤔 Reflective", "💡 Discovery", "⭐ Milestone", "❓ Question"],
                        value=current.get('mood', "☕ Normal"))
                    new_body = st.text_area("Body", value=current.get('body', ''), height=300)
                    new_tags = st.multiselect("Tags", 
                        ['#tasting', '#science', '#recommendation', '#gear', '#cafe', '#learning', '#question'],
                        default=current.get('tags', '').split(',') if current.get('tags') else [])
                    
                    if st.form_submit_button("Update Entry"):
                        update_journal_entry(eid, {
                            'title': new_title,
                            'body': new_body,
                            'mood': new_mood,
                            'tags': ','.join(new_tags),
                            'word_count': len(new_body.split())
                        })
                        del st.session_state['edit_journal_id']
                        st.success("Updated!")
                        st.rerun()

with tab2:
    st.subheader("New Journal Entry")
    
    with st.form("new_journal"):
        title = st.text_input("Title (optional)")
        mood = st.select_slider("Mood", 
            options=["☕ Normal", "🤔 Reflective", "💡 Discovery", "⭐ Milestone", "❓ Question"])
        body = st.text_area("Write here...", height=350)
        
        tags = st.multiselect("Tags", 
            ['#tasting', '#science', '#recommendation', '#gear', '#cafe', '#learning', '#question'])
        
        # Link to archive entry
        archive_df = get_all_entries()
        linked_options = ["None"] + [f"#{r.get('id')} {r.get('coffee_name', '')}" for _, r in archive_df.iterrows()] if not archive_df.empty else ["None"]
        linked = st.selectbox("Link to archive entry (optional)", linked_options)
        
        word_count = len(body.split()) if body else 0
        st.caption(f"{word_count} words • ~{max(1, word_count // 200 + 1)} min read")
        
        if st.form_submit_button("💾 Save Entry", type="primary"):
            data = {
                'title': title,
                'body': body,
                'tags': ','.join(tags),
                'mood': mood,
                'linked_entry_id': None,
                'word_count': word_count
            }
            insert_journal_entry(data)
            st.success("Entry saved!")
            st.balloons()
            st.rerun()