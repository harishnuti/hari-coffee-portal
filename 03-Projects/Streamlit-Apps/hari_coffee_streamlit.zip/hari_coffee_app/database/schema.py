import sqlite3
from .connection import get_connection, is_cloud

def init_db():
    """Create all tables if not exist"""
    conn = get_connection()
    if conn is None:
        return  # Cloud mode - no SQLite
    
    cursor = conn.cursor()
    
    # coffee_archive table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS coffee_archive (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_num INTEGER,
            date TEXT,
            city TEXT,
            cafe_name TEXT,
            coffee_name TEXT,
            varietal TEXT,
            process TEXT,
            roast_level TEXT,
            brew_method TEXT,
            dose_g REAL,
            yield_g REAL,
            ratio TEXT,
            bloom TEXT,
            grinder TEXT,
            price_local TEXT,
            official_notes TEXT,
            your_verdict TEXT,
            technical_enrichment TEXT,
            rating INTEGER DEFAULT 0,
            is_partial INTEGER DEFAULT 0,
            is_draft INTEGER DEFAULT 0,
            sentiment_score REAL DEFAULT 0,
            created_at TEXT,
            updated_at TEXT
        )
    ''')
    
    # beans table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS beans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            roaster TEXT,
            coffee_name TEXT,
            varietal TEXT,
            process TEXT,
            roast_date TEXT,
            purchase_date TEXT,
            weight_g INTEGER,
            weight_remaining_g INTEGER,
            price_sgd REAL,
            where_bought TEXT,
            is_finished INTEGER DEFAULT 0,
            finished_date TEXT,
            final_rating INTEGER,
            created_at TEXT
        )
    ''')
    
    # brew_sessions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS brew_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bean_id INTEGER,
            session_date TEXT,
            brew_method TEXT,
            dose_g REAL,
            yield_g REAL,
            ratio TEXT,
            grinder TEXT,
            temp_c INTEGER,
            tasting_note TEXT,
            rating INTEGER,
            hot_note TEXT,
            mid_note TEXT,
            cool_note TEXT,
            FOREIGN KEY (bean_id) REFERENCES beans(id)
        )
    ''')
    
    # wishlist table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS wishlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            coffee_name TEXT,
            origin TEXT,
            process TEXT,
            varietal TEXT,
            match_percent INTEGER,
            why_fits TEXT,
            estimated_price TEXT,
            where_to_find TEXT,
            is_purchased INTEGER DEFAULT 0,
            purchased_date TEXT
        )
    ''')
    
    # goals table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            description TEXT,
            category TEXT,
            priority TEXT,
            is_complete INTEGER DEFAULT 0,
            complete_date TEXT,
            notes TEXT,
            target_date TEXT
        )
    ''')
    
    # journal_entries table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS journal_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            body TEXT,
            tags TEXT,
            mood TEXT,
            linked_entry_id INTEGER,
            word_count INTEGER,
            created_at TEXT,
            updated_at TEXT
        )
    ''')
    
    # saved_recipes table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS saved_recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_name TEXT,
            origin TEXT,
            varietal TEXT,
            process TEXT,
            brew_method TEXT,
            dose_g REAL,
            yield_g REAL,
            ratio TEXT,
            temp_c INTEGER,
            bloom_g REAL,
            bloom_time_s INTEGER,
            pour_notes TEXT,
            created_at TEXT
        )
    ''')
    
    conn.commit()
    conn.close()