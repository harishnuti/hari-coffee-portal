# Deployment Guide — Hari's Coffee Archive 2026

**Version:** 1.0.1  
**Audience:** Non-technical users + developers

---

## SECTION A — LOCAL SETUP (Step-by-Step)

### Step 1: Install Python 3.9+
- **macOS:** `brew install python3`
- **Windows:** Download from python.org/downloads (check "Add to PATH")
- **Linux:** `sudo apt update && sudo apt install python3 python3-pip python3-venv`

Verify:
```bash
python3 --version
# Should show Python 3.9.0 or higher
```

### Step 2: Download the App
**Option A (Easiest):** Download `hari_coffee_streamlit.zip` from the release and unzip.

**Option B (Recommended for updates):**
```bash
git clone https://github.com/yourusername/hari-coffee-archive.git
cd hari-coffee-archive/hari_coffee_app
```

### Step 3: Install Dependencies
```bash
cd hari_coffee_app
pip install -r requirements.txt
```

Expected output (last lines):
```
Successfully installed pandas-2.2.2 plotly-5.22.0 streamlit-1.35.0 ...
```

### Step 4: Run Locally
```bash
streamlit run app.py
```

Browser will automatically open at: **http://localhost:8501**

### Step 5: First Run Behaviour
- `coffee_archive.db` is automatically created in the app folder
- 31 archive entries are seeded from `data/hari_coffee_master.csv`
- 20 H2 2026 goals are pre-loaded
- 5 wishlist items are pre-loaded
- All 10 pages appear in the sidebar navigation

**You are now ready to use the full application locally.**

---

## SECTION B — STREAMLIT CLOUD DEPLOYMENT

### Step 1: Create GitHub Account (if needed)
Go to github.com → Sign up (free).

### Step 2: Create New Repository
1. Click **+** → New repository
2. Name: `hari-coffee-archive`
3. Visibility: **Private** (recommended)
4. Do **NOT** initialize with README
5. Click "Create repository"

### Step 3: Upload App Files
**Easiest method (no Git CLI):**
1. On the new repo page, click **uploading an existing file**
2. Drag and drop the entire `hari_coffee_app/` folder contents
3. Commit with message: "Initial upload of Hari's Coffee Archive 2026"

### Step 4: Connect to Streamlit Cloud
1. Go to https://share.streamlit.io
2. Sign in with GitHub
3. Click **New app**
4. Select your repository: `hari-coffee-archive`
5. Main file path: `app.py`
6. Click **Deploy**

### Step 5: Your Live URL
Your app will be live at:
```
https://[your-username]-hari-coffee-archive.streamlit.app
```

### Step 6: Understanding Cloud Data Persistence
**Important:** Streamlit Cloud resets the filesystem on every deploy/restart.

- **Committed data:** `data/hari_coffee_master.csv` (always present)
- **Runtime data:** New entries are stored only in `st.session_state` (disappears on refresh)
- **Persistence workflow:**
  1. Add new entries in the app
  2. Go to **Export Hub → Archive Export**
  3. Download the latest CSV
  4. Commit the updated CSV back to GitHub
  5. Cloud app will pick up the new CSV on next load

### Step 7: Updating the App
After making changes locally:
```bash
git add .
git commit -m "Added new entry + updated CSV"
git push
```
Streamlit Cloud will automatically redeploy within 30–60 seconds.

---

## SECTION C — ADDING NEW AUDIT ENTRIES

### Method A: Via the App (Recommended)
1. Open app → **New Entry** page
2. Fill the smart form (city and grinder auto-fill from history)
3. Write your verdict (sentiment score auto-calculates)
4. Click **Submit Entry**
5. Copy the generated **CSV Line** from the success section
6. If on Cloud: Go to Export Hub → Download full CSV → commit to GitHub

### Method B: Via Claude (for complex entries)
1. Paste your tasting notes + technical details to Claude
2. Ask: "Generate a CSV line matching the exact 17-column format of hari_coffee_audit_master_2026.csv"
3. Paste the generated line into the **Import CSV** function in Settings

---

## SECTION D — TROUBLESHOOTING (15 Common Issues)

**1. Error: "ModuleNotFoundError: No module named 'streamlit'"**
- Fix: `pip install -r requirements.txt`

**2. Error: "Database locked"**
- Fix: Close any other terminal/window running the same app

**3. New entries disappear after refresh (Cloud)**
- Fix: This is expected. Export CSV from Export Hub and commit to GitHub.

**4. Charts not rendering**
- Fix: Update Plotly: `pip install --upgrade plotly`

**5. "calculate_sentiment" ImportError**
- Fix: Already fixed in v1.0.1. Pull latest code.

**6. App looks broken / wrong colors**
- Fix: Clear browser cache (Ctrl+Shift+R)

**7. "FileNotFoundError: hari_coffee_master.csv"**
- Fix: Ensure `data/hari_coffee_master.csv` exists in the app folder

**8. Slider / number input not working**
- Fix: Streamlit version too old. Run `pip install --upgrade streamlit`

**9. "Permission denied" on macOS/Linux**
- Fix: `chmod +x` not needed. Run with `python3 -m streamlit run app.py`

**10. Cloud app shows old data**
- Fix: Hard refresh browser (Ctrl+Shift+R) or redeploy from GitHub

**11. "st.session_state" errors**
- Fix: Restart the app (in terminal: Ctrl+C then `streamlit run app.py` again)

**12. Export buttons do nothing**
- Fix: Browser popup blocker — allow downloads for the site

**13. Goals not saving**
- Fix: In Cloud mode, goals are session-only. Export JSON backup regularly.

**14. "No module named 'python_dateutil'"**
- Fix: `pip install python-dateutil`

**15. App crashes on first run**
- Fix: Delete `coffee_archive.db` and restart (will re-seed cleanly)

---

**Need help?** Open an issue on GitHub or contact Hari directly.

**Last updated:** 20 May 2026 (v1.0.1)