import pandas as pd
from datetime import datetime

def generate_csv_line(entry: dict) -> str:
    """Generates exact 17-column CSV line matching master format"""
    fields = [
        entry.get('date', ''),
        entry.get('city', ''),
        entry.get('cafe_name', ''),
        entry.get('coffee_name', ''),
        entry.get('varietal', ''),
        entry.get('process', ''),
        entry.get('roast_level', ''),
        entry.get('brew_method', ''),
        str(entry.get('dose_g', '')),
        str(entry.get('yield_g', '')),
        entry.get('ratio', ''),
        entry.get('bloom', ''),
        entry.get('grinder', ''),
        entry.get('price_local', ''),
        entry.get('official_notes', ''),
        entry.get('your_verdict', ''),
        entry.get('technical_enrichment', '')
    ]
    quoted = []
    for f in fields:
        f = str(f).replace('"', '""')
        if ',' in f or '"' in f or '\n' in f:
            quoted.append(f'"{f}"')
        else:
            quoted.append(f)
    return ','.join(quoted)

def generate_gemini_prompt(entry: dict) -> str:
    """Generates Gemini infographic prompt for any entry"""
    coffee = entry.get('coffee_name', 'Specialty Coffee')
    cafe = entry.get('cafe_name', 'Specialty Cafe')
    verdict = entry.get('your_verdict', 'Exceptional cup with remarkable clarity.')
    
    return f"""Create a cinematic 16:9 dark-amber aesthetic infographic for a specialty coffee archive entry.

TITLE: "{coffee} @ {cafe}"

SUBTITLE: {entry.get('date', '')} • {entry.get('city', '')} • {entry.get('process', '')} Process • {entry.get('varietal', '')}

SECTION 1 — THE BEAN
• Origin: {entry.get('city', 'Unknown')}
• Varietal: {entry.get('varietal', 'Unknown')}
• Process: {entry.get('process', 'Unknown')}
• Roast: {entry.get('roast_level', 'Unknown')}

SECTION 2 — BREW PARAMETERS
• Method: {entry.get('brew_method', 'Unknown')}
• Grinder: {entry.get('grinder', 'Unknown')}
• Ratio: {entry.get('ratio', '1:15')}
• Temp: {entry.get('brew_temp', '92°C')}
• Dose → Yield: {entry.get('dose_g', 15)}g → {entry.get('yield_g', 225)}g
• Bloom: {entry.get('bloom', '30g / 30s')}

SECTION 3 — TASTING NOTES
Official Roaster Notes: {entry.get('official_notes', 'N/A')}
Your Verdict: {verdict[:250]}

SECTION 4 — TECHNICAL ENRICHMENT
{entry.get('technical_enrichment', 'Precision extraction with controlled thermal profiling and optimal degassing window.')}

SECTION 5 — METRICS
Sentiment Score: {entry.get('sentiment_score', 8.5)}/10
Overall Rating: {entry.get('rating', 4)}★
Partial Entry: {'Yes' if entry.get('is_partial') else 'No'}

STYLE SPEC: Dark coffee background (#0d0d0d), elegant gold accents (#c9a84c), Playfair Display serif typography, subtle steam/thermal gradient effects, professional specialty coffee magazine aesthetic. High contrast, cinematic volumetric lighting, 16:9 aspect ratio, 300dpi print quality."""

def generate_instagram_caption(entry: dict, tone='balanced') -> str:
    """Generates Instagram caption in Hari's voice"""
    coffee = entry.get('coffee_name', 'this coffee')
    verdict = entry.get('your_verdict', '')
    tech = entry.get('technical_enrichment', '')
    
    base = f"""☕ {coffee}

{verdict[:180]}...

Brewed on {entry.get('brew_method', 'V60')} with {entry.get('grinder', 'precision grinder')} at {entry.get('ratio', '1:15')}.

{tech[:120] if tech else 'Clean extraction with beautiful thermal layering.'}

Sentiment: {entry.get('sentiment_score', 8.5)}/10 • Rating: {entry.get('rating', 4)}★

#SpecialtyCoffee #CoffeeArchive #PourOver #Geisha #CoffeeJournal #ThirdWaveCoffee #SingaporeCoffee #BaliCoffee #KenyaAA #EthiopiaCoffee #PanamaGeisha #CoffeeTasting #FilterCoffee #CoffeeLover #HariCoffee2026 #SpecialtyCoffeeSingapore"""
    
    return base[:2200]

def generate_twitter_thread(entry: dict) -> list:
    """Returns list of 8 tweets (280 chars each)"""
    coffee = entry.get('coffee_name', 'Specialty Coffee')
    verdict = entry.get('your_verdict', '')[:100]
    
    tweets = [
        f"1/8 ☕ New archive entry: {coffee} @ {entry.get('cafe_name', 'Unknown')}\n\n{verdict}...\n\nSentiment: {entry.get('sentiment_score', 8.5)}/10",
        f"2/8 The bean: {entry.get('varietal', 'Unknown')} from {entry.get('city', 'Unknown')}. {entry.get('process', 'Unknown')} process. Roast: {entry.get('roast_level', 'Unknown')}.",
        f"3/8 Brewed on {entry.get('brew_method', 'V60')} with {entry.get('grinder', 'Unknown')} at {entry.get('ratio', '1:15')}. Temp: {entry.get('brew_temp', '92°C')}.",
        f"4/8 Official notes: {entry.get('official_notes', 'N/A')[:80]}",
        f"5/8 My verdict: {verdict}...",
        f"6/8 Technical: {entry.get('technical_enrichment', 'Precision extraction.')[:100]}",
        f"7/8 This one sits at #{entry.get('id', '?')} in the 2026 archive. Building the map one cup at a time.",
        f"8/8 Full entry + Gemini prompt + CSV line in the Export Hub. Link in bio. #CoffeeArchive #SpecialtyCoffee"
    ]
    return tweets

def generate_maps_review(entry: dict, variant='accessible') -> str:
    """Returns Google Maps review text"""
    coffee = entry.get('coffee_name', 'the coffee')
    verdict = entry.get('your_verdict', '')
    
    if variant == 'technical':
        return f"""Exceptional {coffee}. {verdict[:120]}. Brewed on {entry.get('brew_method')} at {entry.get('ratio')} with {entry.get('grinder')}. Technical notes: {entry.get('technical_enrichment', '')[:80]}. Highly recommended for serious coffee enthusiasts. 5/5"""
    elif variant == 'short':
        return f"""{coffee} was outstanding. {verdict[:80]}... Perfect extraction. Will return. 5/5"""
    else:
        return f"""Had the most incredible {coffee} here today. {verdict[:150]}... The barista really knows their craft. The attention to detail in every cup is obvious. If you're a coffee lover in {entry.get('city', 'Singapore')}, this is a must-visit. 5/5"""

def generate_share_card(entry: dict) -> str:
    """Returns formatted text share card for WhatsApp"""
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
☕ HARI'S COFFEE ARCHIVE 2026
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{entry.get('coffee_name', 'Specialty Coffee')}
@ {entry.get('cafe_name', 'Unknown Cafe')}
{entry.get('city', '')} • {entry.get('date', '')}

{entry.get('your_verdict', 'Exceptional cup.')[:150]}...

Process: {entry.get('process', 'Unknown')}
Ratio: {entry.get('ratio', '1:15')}
Sentiment: {entry.get('sentiment_score', 8.5)}/10 ★{entry.get('rating', 4)}

🔗 Full entry in archive
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""